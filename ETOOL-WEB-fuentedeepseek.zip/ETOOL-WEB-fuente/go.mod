module etoolweb

go 1.24
