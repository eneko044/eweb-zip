package main

import (
	"encoding/binary"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestCleanHost(t *testing.T) {
	cases := map[string]string{
		"Ejemplo.com":                  "ejemplo.com",
		"https://app.ejemplo.com/x?y":  "app.ejemplo.com",
		"ejemplo.com:8443/ruta":        "ejemplo.com",
		"ejemplo.com.":                 "ejemplo.com",
		"203.0.113.10":                 "203.0.113.10",
		"2001:db8::1":                  "2001:db8::1",
		"[2001:db8::1]":                "2001:db8::1",
		"[2001:db8::1]:443":            "2001:db8::1",
		"https://[2001:db8::1]:8443/a": "2001:db8::1",
		"  ":                           "",
	}
	for in, want := range cases {
		if got := cleanHost(in); got != want {
			t.Errorf("cleanHost(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestValidDomain(t *testing.T) {
	for _, d := range []string{"ejemplo.com", "a.b.ejemplo.co.uk", "xn--bcher-kva.example", "_dmarc.ejemplo.com"} {
		if !validDomain(d) {
			t.Errorf("validDomain(%q) = false", d)
		}
	}
	for _, d := range []string{"", "localhost", "-a.com", "a..com", "ejemplo.com/x", "a b.com", "ejemplo.123"} {
		if validDomain(d) {
			t.Errorf("validDomain(%q) = true", d)
		}
	}
}

func TestSubSetAdd(t *testing.T) {
	s := &subSet{m: map[string]map[string]bool{}}
	for _, n := range []string{"*.ejemplo.com", "www.ejemplo.com", "WWW.Ejemplo.com.", "evilejemplo.com",
		"admin@ejemplo.com", "ejemplo.com", "a.b.ejemplo.com", ""} {
		s.add(n, "ejemplo.com", "test")
	}
	got := strings.Join(s.names(), ",")
	if want := "a.b.ejemplo.com,ejemplo.com,www.ejemplo.com"; got != want {
		t.Errorf("subdominios = %q, want %q", got, want)
	}
	// Varias fuentes para un mismo nombre se acumulan sin duplicar.
	s.add("www.ejemplo.com", "ejemplo.com", "otra")
	if srcs := s.sources("www.ejemplo.com"); len(srcs) != 2 {
		t.Errorf("fuentes = %v, want 2", srcs)
	}
}

func TestNormalizePath(t *testing.T) {
	cases := map[string]string{
		"https://ejemplo.com/admin/?x=1": "/admin/?x=1",
		"/.git/HEAD":                     "/.git/HEAD",
		"wp-login.php":                   "/wp-login.php",
		"/":                              "",
		"https://ejemplo.com/":           "",
		"":                               "",
	}
	for in, want := range cases {
		if got := normalizePath(in); got != want {
			t.Errorf("normalizePath(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestHostFromURL(t *testing.T) {
	cases := map[string]string{
		"https://A.Ejemplo.com/x": "a.ejemplo.com",
		"ejemplo.com:8080/y":      "ejemplo.com",
		"http://[2001:db8::1]/z":  "2001:db8::1",
		"not a url with spaces":   "",
	}
	for in, want := range cases {
		if got := hostFromURL(in); got != want {
			t.Errorf("hostFromURL(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestSetProdVer(t *testing.T) {
	cases := []struct{ in, prod, ver string }{
		{"OpenSSH_8.2p1", "OpenSSH", "8.2p1"},
		{"nginx/1.18.0 (Ubuntu)", "nginx", "1.18.0"},
		{"Apache/2.4.49 (Unix)", "Apache", "2.4.49"},
		{"Microsoft-IIS/10.0", "Microsoft-IIS", "10.0"},
		{"cloudflare", "cloudflare", ""},
	}
	for _, c := range cases {
		var pr portResult
		setProdVer(&pr, c.in)
		if pr.Product != c.prod || pr.Version != c.ver {
			t.Errorf("setProdVer(%q) = %q %q, want %q %q", c.in, pr.Product, pr.Version, c.prod, c.ver)
		}
	}
	var pr portResult
	setProdVer(&pr, "   ") // no debe provocar pánico
}

func TestParsePorts(t *testing.T) {
	if p, err := parsePorts(map[string]any{}); err != nil || len(p) != len(commonPorts) {
		t.Fatalf("por defecto: %v %v", p, err)
	}
	p, err := parsePorts(map[string]any{"ports": []any{80.0, 443.0, 80.0}})
	if err != nil || len(p) != 2 {
		t.Fatalf("dedupe: %v %v", p, err)
	}
	for _, bad := range []any{0.0, 70000.0, 1.5, "80"} {
		if _, err := parsePorts(map[string]any{"ports": []any{bad}}); err == nil {
			t.Errorf("puerto %v aceptado", bad)
		}
	}
}

// dnsAnswer construye una respuesta DNS mínima con un registro de respuesta.
func dnsAnswer(qtype uint16, rdata []byte) []byte {
	q, _ := buildQuery("ejemplo.com", qtype)
	msg := append([]byte{}, q...)
	msg[2] |= 0x80                         // QR
	binary.BigEndian.PutUint16(msg[6:], 1) // ANCOUNT
	msg = append(msg, 0xC0, 12)            // nombre → puntero a la pregunta
	rr := make([]byte, 10)
	binary.BigEndian.PutUint16(rr[0:], qtype)
	binary.BigEndian.PutUint16(rr[2:], 1)
	binary.BigEndian.PutUint16(rr[8:], uint16(len(rdata)))
	msg = append(msg, rr...)
	return append(msg, rdata...)
}

func TestParseSOAandCAA(t *testing.T) {
	soa := []byte{2, 'n', 's', 0xC0, 12, 10, 'h', 'o', 's', 't', 'm', 'a', 's', 't', 'e', 'r', 0xC0, 12}
	soa = append(soa, make([]byte, 20)...)
	if got := parseSOA(dnsAnswer(6, soa)); got != "primary ns.ejemplo.com · resp hostmaster.ejemplo.com" {
		t.Errorf("parseSOA = %q", got)
	}
	caa := append([]byte{0, 5}, []byte("issueletsencrypt.org")...)
	if got := parseCAA(dnsAnswer(257, caa)); len(got) != 1 || got[0] != `0 issue "letsencrypt.org"` {
		t.Errorf("parseCAA = %q", got)
	}
	// Mensajes truncados no deben provocar pánico.
	full := dnsAnswer(257, caa)
	for i := 0; i < len(full); i++ {
		parseCAA(full[:i])
		parseSOA(full[:i])
	}
}

func TestGuard(t *testing.T) {
	ok := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	h := guard("127.0.0.1:8787", "secreto", ok)
	do := func(method, host, path, origin, token, ctype string) int {
		r := httptest.NewRequest(method, "http://"+host+path, strings.NewReader("{}"))
		r.Host = host
		if origin != "" {
			r.Header.Set("Origin", origin)
		}
		if token != "" {
			r.Header.Set("X-ETOOL-Token", token)
		}
		if ctype != "" {
			r.Header.Set("Content-Type", ctype)
		}
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		return w.Code
	}
	tests := []struct {
		name                                     string
		method, host, path, origin, token, ctype string
		want                                     int
	}{
		{"panel", "GET", "127.0.0.1:8787", "/", "", "", "", 200},
		{"localhost", "GET", "localhost:8787", "/", "", "", "", 200},
		{"rebinding", "GET", "atacante.example:8787", "/", "", "", "", 403},
		{"api ok", "POST", "127.0.0.1:8787", "/api/dns", "http://127.0.0.1:8787", "secreto", "application/json", 200},
		{"api sin token", "POST", "127.0.0.1:8787", "/api/dns", "", "", "application/json", 403},
		{"api token malo", "POST", "127.0.0.1:8787", "/api/dns", "", "otro", "application/json", 403},
		{"api origen ajeno", "POST", "127.0.0.1:8787", "/api/scan", "https://evil.example", "secreto", "application/json", 403},
		{"api text/plain", "POST", "127.0.0.1:8787", "/api/scan", "", "secreto", "text/plain", 415},
		{"api GET", "GET", "127.0.0.1:8787", "/api/health", "", "secreto", "", 405},
	}
	for _, tc := range tests {
		if got := do(tc.method, tc.host, tc.path, tc.origin, tc.token, tc.ctype); got != tc.want {
			t.Errorf("%s: código %d, want %d", tc.name, got, tc.want)
		}
	}
}

func TestScanRequiresAuthorization(t *testing.T) {
	if _, err := hScan(t.Context(), map[string]any{"target": "127.0.0.1"}); err == nil {
		t.Fatal("el escaneo sin authorized=true debe rechazarse")
	}
}
